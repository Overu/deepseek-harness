# 画布插件数据传输规范

本规范约束插件 Host、Harness Client、内置画布页面和画布服务端的交互。标为“候选”的服务端字段来自现有调研文档，只有服务端联调确认后才能成为实现依赖。

## 身份与寻址

| 数据 | 表示 | 规则 |
| --- | --- | --- |
| canvasId | 正 Long 的十进制字符串 | 不转为 Number；每个请求、事件、标签和产物关联显式携带 |
| nodeId | 旧画布数据中的原始字符串 | 与 canvasId 分开验证，不改写或重编序号 |
| taskId / runId | 服务端任务标识 | 与 canvasId 不可互换；任务结果要回带 canvasId |
| resourceAddress | `dsh-resource://canvas/<canvasId>` | 同一 ID 聚焦原标签；不同 ID 占不同标签 |
| requestId | 每次命令唯一的客户端标识 | 记录排障关联；只有服务端持久去重或查询结果时才提供幂等语义 |

修改与执行工具必须显式接受 canvasId。只读工具可以从当前可见标签预填 ID，但工具执行前仍把解析后的 ID固定在请求中；页面切换不能改变飞行中的请求目标。图片卡片或产物链接由生成时保存的 canvasId 打开标签，不解析图片 URL。

## 客户端登录与本机路由

Host 向 Shell 私有进程通道按需取得当前登录 Token，只发往配置允许的 Gateway 主机；不跟随跨源重定向。Token 不进入 iframe、localStorage、URL、日志、工具参数或结果。Host 每个本机路由先调用 Core Connection 的 `requestRejection`，再处理路径和请求体；服务端仍对用户和 canvasId 做读写授权。测试/生产环境来自桌面运行环境，不能由页面参数切换。

当前画布 API 经同源 `/desktop-canvas/api/legacy/<业务路径>` 转发。Host 只接受 GET、POST、PUT，目标固定为当前环境的测试或生产 Gateway；路径限于 `/game-ai-editor-center/api/`、`/game-ai-editor-center/upload/`、`/game-ai-editor-center/workflow-tool/`、`/game-ai-editor-center/upscale/`、`/material-server/asset/`、`/order-server/api/cost/` 和 `/account-service/api/account/` 前缀。这个范围涵盖画布编辑、资产、工具、上传相关 JSON 接口及余额/计费请求；其他整站账户、支付等路径和任意目标 URL 均不转发。Host 使用同一桌面登录态，无需按接口再次授权；上游仍决定具体操作权限。

模型参数另经只读同源 `GET /desktop-canvas/api/model-params` 获取。Host 按当前环境分别读取旧 Web 使用的固定测试/生产模型配置 CDN，并校验响应为有大小上限的 JSON；这个公开配置请求不携带桌面 Token，也不接受页面传入目标 URL。节点底栏的模型、参数和费用查询依赖该配置。

画布左上角的“分享”直接调用旧业务 `POST /game-ai-editor-center/api/canvas/share`，提交当前画布 ID、名称、缩略图和当前节点/连线图；成功后用返回的分享码构造完整 `/share/<code>` 链接，不把画布 ID 当作分享码。链接域名由 Host 按桌面环境注入受保护页面的 `desktop-canvas-web-origin` 元信息（测试 `https://dynsight-test.insight-aigc.com`，生产 `https://dynsight.insight-aigc.com`），页面不能通过参数切换环境。自动复制失败时，页面保留完整链接和再次复制入口，不报告复制成功。分享不经过社区发布流程；接口权限及链接可见范围由画布服务端控制。客户端仍须对分享内容和结果按敏感数据处理。

Host 限制静态资源路径、API 方法、JSON 请求体大小、JSON 响应类型和大小及上游地址。失败只返回状态、稳定错误码和可展示的简短信息，不回传包含凭据的原始上游请求。旧 API 适配层支持 GET、POST、PUT 的 JSON 请求，仍不支持 FormData 文件上传或绝对 URL 直连；路径范围扩大不等于这些能力已接通。当前 `/desktop-canvas/view`、`/desktop-canvas/app.js` 与 `/desktop-canvas/api/snapshot` 均实施浏览器会话检查；snapshot 额外要求当前桌面登录态。

## iframe 到 Harness Client

消息信封：

```json
{
  "protocolVersion": 1,
  "type": "canvas.node.select",
  "canvasId": "2873",
  "requestId": "2bd6b2b5-d19c-4b70-b17d-72ece2e8c419",
  "payload": { "id": "node-1", "title": "图片 1", "type": "image", "value": "https://example.com/image.jpg" }
}
```

Client 在读 payload 前确认 `event.origin === location.origin`、`event.source === 当前 iframe.contentWindow`、版本、类型及 canvasId 与标签一致。节点摘要长度有上限；写入当前对话输入框时保留已有草稿。消息只表示用户显式选择节点，不自动发送对话。后续新增消息类型必须定义版本兼容和拒绝未知类型的行为。

## 画布服务与事件流

首个真实接口候选为 `POST /game-ai-editor-center/api/canvas/get`，请求 `{ "id": "2873" }`，响应的 `data.data` 是 JSON 字符串图，包含 nodes 和 edges。实现层要验证外层成功码、画布 ID、图结构和任务状态；页面使用完整图，工具结果只返回有上限的摘要。准确响应字段由服务端确认。

订阅候选为 `POST /game-ai-editor-center/api/canvas/subscribe`，请求 `{ "id": "2873" }`，返回 `text/event-stream`。**服务端确认该接口目前仍处技术调研阶段，尚未研发。** 后续实现时用 `fetch` 流读取 POST 订阅，不能假设浏览器 `EventSource` 能发 POST 或自定义鉴权头。Host 逐块转发、禁用缓冲、跟随客户端关闭中止上游；连接建立前的 JSON 错误必须作为错误响应处理，不能当作 SSE 帧。

候选事件 `canvas.connected`、`canvas.changed`、`canvas.checkpoint`、`heartbeat`、`canvas.unavailable`。事件不得作为图 patch：首次连接、重连、标签重新激活、`changed` 和版本/任务状态不同的 `checkpoint` 均触发 GET 快照。单画布 GET 单飞行，合并短时间重复通知；较旧响应不能覆盖较新状态。心跳只维持连接，不触发 GET。失权/删除时停止重连并清除不可再访问的数据。

活动标签订阅当前画布；标签卸载或插件停止时中止订阅。服务端任务在后台继续，不依赖标签存活；再次打开以 GET 恢复。若编辑器有未保存节点、拖动或保存错误，远端快照不得静默覆盖本地草稿；先保留冲突状态，再由用户或明确的合并规则处理。

## 写入与错误恢复

读请求可有限重试；写请求的响应超时或断开属于“结果未知”，不能自动重发创建、保存或生成。发生版本冲突时重新读取并展示冲突，不盲目复用旧 baseVersion。只有服务端确认了持久 requestId 去重或按 requestId 查询结果，才能为特定写命令设计自动恢复。

联调时按身份错误、权限错误、画布不存在、版本冲突、限流、服务不可用和结果未知分别验收。Gateway/Ingress 必须验证 POST SSE 逐帧转发、心跳、空闲超时、取消连接和多实例通知。Demo 的本机事件流不构成这些验收的证据。
