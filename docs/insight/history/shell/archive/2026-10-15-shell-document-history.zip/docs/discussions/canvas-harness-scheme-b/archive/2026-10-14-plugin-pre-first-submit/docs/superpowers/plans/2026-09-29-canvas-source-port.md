# Canvas Source Port Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在独立插件包内运行旧画布的实际编辑器，使用当前桌面登录态加载已有画布、基础编辑、保存并重开确认。

**Architecture:** `canvas-app` 独立 Vite 构建 React 19 画布 Web，作为同一个插件归档内的 iframe 静态资源。复制后的旧业务模块尽量保持结构，入口/认证/请求层集中适配；Host 认证本机请求并按明确允许列表调用固定 Gateway。Harness Client 继续使用现有右栏和 `postMessage` 通道。

**Tech Stack:** Vite 7、React 19、Tailwind 4、`@xyflow/react` 12、Fabric 6、Less、TypeScript、Node/esbuild、DSH Host WebServer。

## Global Constraints

- 只在 `/Users/boxser.shi/Documents/harness/desktop-canvas-plugin` 的独立分支实施；读取旧仓库不修改旧仓库，不动 Shell/Core 主干。
- 当前文档阶段只制定计划。开始复制旧源码须等用户明确启动迁入实施。
- 首版只验收已有画布的加载、基础编辑、`partialUpdate`、显式保存、关闭重开；SSE、生成、素材库与完整多标签不属于完成门槛。
- `canvas-app` 不与 `insight-web-platform` 建立 workspace、submodule、文件 alias、构建时读取或自动同步关系。
- iframe 不接收 Token；Host 在每次 API 请求时获取当前客户端凭据，只访问当前环境固定 Gateway。
- 首版保留旧 `flowStore` 的版本号、变更队列和冲突处理语义；不重写节点、连线与序列化算法。
- 每项任务都用相应的构建/测试或实际桌面操作验收，记录无法自动覆盖的现象。

## 文件责任图

| 文件/目录 | 责任 |
| --- | --- |
| `canvas-app/PORTING-MANIFEST.md` | 来源提交、文件及依赖版本/许可、刻意变更和包体积记录 |
| `canvas-app/legacy/src/**`、`canvas-app/legacy/tailwind.config.js` | 一次性复制的画布业务闭包，尽量维持相对目录 |
| `canvas-app/package.json`、`pnpm-lock.yaml`、`vite.config.ts`、`index.html` | 独立安装、单入口构建和资源基址 |
| `canvas-app/src/main.tsx`、`canvas-app/src/canvas-router.tsx` | 挂载最小路由和实际必要的 Provider |
| `canvas-app/legacy/src/api/request.ts`、`canvas-app/legacy/src/contexts/AuthContext.tsx` | 集中的桌面请求/鉴权适配接缝 |
| `scripts/build.mjs`、根 `package.json` | 按序构建三产物并打入一个归档 |
| `src/host/page-route.ts` | 认证后服务页面及 Vite 构建资源 |
| `src/host/gateway-route.ts`、`src/host/index.ts` | 限定 API 路径/方法、鉴权、调用 Gateway、回传业务响应 |
| `test/page-route.test.mjs`、`test/gateway-route.test.mjs` | 静态资源与网关边界的针对性测试 |

旧源码的最终文件列表由任务 1 冻结；不要为了符合预估数字裁掉实际构建/运行需要的模块。

### Task 1: 冻结来源和迁入闭包

**Files:** Create `canvas-app/PORTING-MANIFEST.md`; later copy actual files into `canvas-app/legacy/src`, `canvas-app/legacy/tailwind.config.js`, `canvas-app/public`.

**Interfaces:** 输出本仓库内可独立构建的旧源码清单。文件清单每项记录旧路径、新路径、源 SHA-256；记录旧提交、旧锁文件中用到的包版本及其许可。

- [ ] **Step 1:** 迁入当天对旧仓库运行 `git status --short`、`git rev-parse HEAD`；若来源有未提交改动，固定干净提交而非复制工作树混合状态。记录提交号到清单。
- [ ] **Step 2:** 从 `src/routes/Canvas.tsx` 做静态导入候选闭包，检查 `src/components/canvasFlow/index.tsx` 的动态导入、CSS、静态素材、worker、wasm 与直接 `fetch`。先排除 `src/router/routeConfig.ts` 整站路由诱发的假依赖，再按 Vite 构建错误补齐真实闭包。把旧 `src` 路径映射为 `canvas-app/legacy/src`，保留同级目录层次。
- [ ] **Step 3:** 逐个复制实际需要的源文件和静态素材，不复制 `.env.*`、旧 `dist`、旧 `node_modules`、旧登录入口或额外 HTML。用来源 Git 对象和本仓库文件计算 SHA-256 并比对，随后在清单记录因接入所做的修改。复制后临时移走/断开旧仓库路径，后续构建必须仍可运行。
- [ ] **Step 4:** 列出闭包涉及的 npm 包名和旧锁文件解析版本；按实际构建确定直接依赖，记录许可证和需保留的字体/图片许可。`git diff --check` 后提交来源清单与复制文件。验收：复制文件的来源和改变可追溯，旧项目工作树仍干净。

### Task 2: 独立 Canvas Web 单入口构建

**Files:** Create `canvas-app/package.json`, `canvas-app/pnpm-lock.yaml`, `canvas-app/vite.config.ts`, `canvas-app/index.html`, `canvas-app/src/main.tsx`, `canvas-app/src/canvas-router.tsx`; modify copied `canvas-app/legacy/src/contexts/AuthContext.tsx` only to remove the whole-site router dependency; copy required stylesheet/config under `canvas-app/legacy`.

**Interfaces:** 构建命令在 `canvas-app` 内输出 `dist/index.html` 和带哈希的 `dist/assets/*`；唯一浏览器入口使用 `/desktop-canvas/` 资源基址，路由参数为原始十进制 `canvasId` 字符串。

- [ ] **Step 1:** 子项目锁定旧仓库已解析的 React 19、Vite 7、Tailwind 4、React Flow 12、Fabric 6 等必要版本；从旧 `pnpm-lock.yaml` 的实际包版本重建子项目锁文件。`pnpm install --frozen-lockfile` 在独立子项目通过，不要求根项目安装旧 Web 依赖。
- [ ] **Step 2:** 配置单 HTML 入口、`base: '/desktop-canvas/'`、`@` 指向 `canvas-app/legacy/src`；只纳入实际用到的 React/Tailwind/SVGR/Less 与 worker/wasm 支持。保留旧 CSS 的 `@config` 指向复制后的 Tailwind 配置，删去旧多页面/全站版本更新相关构建插件。
- [ ] **Step 3:** 挂载旧 `CanvasFlow` 与 `ReactFlowProvider`，以最小 `/canvas/$id` 路由提供 `useParams/useNavigate/useLocation`，只加入编译和运行所需 Provider。复制后的认证上下文不再导入整站 `routeConfig`、读取旧 Web Token 或触发旧登录页；当前页面会话由 Host 的受保护 API 决定。保留 `useWorkflowTabGuard` 现有逻辑直到实际右栏切换验收。
- [ ] **Step 4:** 运行 `pnpm --dir canvas-app build`。修复只因脱离整站产生的导入、样式和资源错误；检查 `dist/index.html` 引用均以 `/desktop-canvas/` 开头，并验证旧 Web 项目目录不可用时仍构建。提交独立构建。验收：无整站 HTML 入口和旧项目磁盘路径。

### Task 3: 将 Vite 产物装入现有插件页面路由

**Files:** Modify `scripts/build.mjs`, root `package.json`, `src/host/page-route.ts`, `test/page-route.test.mjs`; remove placeholder source `canvas-app/app.js` once real bundle is served.

**Interfaces:** `GET /desktop-canvas/view?id=<canvasId>` 返回构建 HTML；`GET /desktop-canvas/assets/<hashed-file>` 返回打包资源。原 `/desktop-canvas/api/snapshot` 不回归。Core WebServer 对 exact 路由优先、随后匹配最长 prefix；网关可另注册 `/desktop-canvas/api/legacy` prefix。

- [ ] **Step 1:** 在 `test/page-route.test.mjs` 增加失败测试：未认证请求不读文件；合法 HTML/JS/CSS/字体分别得到正确 MIME；`../`、编码穿越、非白名单扩展、POST 请求返回拒绝；不存在资源返回 404。测试必须覆盖构建后的目录结构，而不是只覆盖旧 `app.js`。
- [ ] **Step 2:** 让根 `npm run build` 先执行 Canvas Web 安装依赖前置检查及 Vite build，再执行现有 Host/Client esbuild；不再清空真实 `dist` 后复制占位资源。根包的 `files` 继续只装 `canvas-app/dist`，不带子项目源码和 `node_modules`。
- [ ] **Step 3:** `pageHandler` 只读取构建目录内的已知文件，先进行 `requestRejection`、方法检查、路径规范化和实际路径界限检查，再读取文件；对 HTML 禁缓存，对哈希资源按构建版本缓存。依据实际产物设置 CSP 中的脚本、样式、图片、媒体、worker 来源，不开放任意脚本源。
- [ ] **Step 4:** 运行 `node --import tsx --test test/page-route.test.mjs`、`npm run build`、`npm pack --dry-run`；确认包中有 HTML、JS、CSS、字体/wasm/worker 实际需要的资源，而没有旧源码和 Source Map。提交 Host 静态装载改动。

### Task 4: 增加明确允许的画布网关路由

**Files:** Create `src/host/gateway-route.ts`, `test/gateway-route.test.mjs`; modify `src/host/index.ts`; reuse `src/host/desktop-token.ts` and the environment selection convention in `src/host/canvas-get.ts`.

**Interfaces:** `GET|POST /desktop-canvas/api/legacy/<allowed-service-path>` 仅转发允许列表中的方法与服务路径，并返回上游原始状态、`content-type` 与响应体。首版允许列表从以下实际挂载/保存请求起步：POST `game-ai-editor-center/api/canvas/get`、POST `.../canvas/partialUpdate`、POST `.../canvas/saveOrUpdate`、POST `.../v2/workflow/listNodeSetting`、GET `.../v2/workflow/listModelNodeSetting`、GET `.../v2/workflow/listToolNodeSetting`、POST `.../tone/list`、GET `order-server/api/cost/getAllRule`。运行时发现额外必需路径，要逐条补测试和理由，不能改成通配代理。

- [ ] **Step 1:** 为 Gateway handler 写失败测试：未认证不取 Token、不读请求体、不请求上游；未列入路径/错误方法拒绝；路径转义/绝对 URL 拒绝；有效请求在固定 test/prod Gateway 转发方法、查询串、JSON body，并注入当前桌面 Token 而非 iframe 提供的 Token。
- [ ] **Step 2:** 添加响应测试：`code: SUCCESS` 的原始 `data` 字段不被压缩成节点摘要；HTTP 401/403、业务版本冲突、超时和上游断连分别按原状态/可读错误返回；客户端关闭时取消上游请求。请求/响应体上限用测试画布实际体积选定并测试超过上限的行为。
- [ ] **Step 3:** 实现 `gateway-route.ts` 并在 `src/host/index.ts` 注册更长的 `/desktop-canvas/api/legacy` prefix。Host 每次请求先调用 `connection.requestRejection`，再调用 `desktopToken(signal)`；上游 `origin`/`referer` 与当前环境对应，不记录 Token、完整图或媒体 URL。不自动重试写请求。
- [ ] **Step 4:** 运行聚焦测试、`npm run typecheck`、`npm test`。在 Core 的 WebServer 匹配语义下验证 Gateway prefix 不被页面 prefix 吞掉，现有 snapshot exact 路由仍可达；提交路由与测试。

### Task 5: 把旧请求层接到 Host，保留画布保存算法

**Files:** Modify copied `canvas-app/legacy/src/api/request.ts` and only the first-milestone direct-fetch call sites if any; inspect `canvas-app/legacy/src/api/workflow.ts`, `canvas-app/legacy/src/store/flowStore.ts`, `canvas-app/legacy/src/components/canvasFlow/utils/toolUtil.ts` without重写保存逻辑；add focused adapter tests under `canvas-app` if request transport can be tested without mounting the full canvas.

**Interfaces:** 旧业务继续调用 `request<T>(url, data, config)`、`get`、`post`，仍获得 `code/data/msg` 的原响应对象。`url` 只能映射到 `/desktop-canvas/api/legacy/<allowed-service-path>`，`config.fullUrl` 或直接 `fetch` 不得绕过桌面认证。HTTP 401 呈现重新登录提示；业务版本冲突保持可识别。

- [ ] **Step 1:** 列出首版闭包内对旧 `request/get/post/AuthExpiredError` 的引用，记录 `fullUrl`、FormData、直接 `fetch`、`VITE_MODEL_PARAMS_URL` 是否实际运行。用可控 fetch 的聚焦测试先覆盖 POST get、GET 配置、401 和保存错误；确保响应对象保留旧字段而不变成当前摘要 `CanvasSnapshot`。
- [ ] **Step 2:** 在复制后的单一请求文件集中替换 API 基址和旧 Token/cookie/refresh/登录跳转逻辑，不批量改写业务 API 文件。页面上的直接网络请求若属于首版路径，定点改为同源 Host 通道；若属于未开放工具入口，明确隐藏或提示，不静默直连旧 Web Gateway。
- [ ] **Step 3:** 保留 `flowStore` 的 `versionNumber`、mutation queue 和 `toolUtil` 的 `partialUpdate`/`saveCanvas` 调用序列。确认节点位置变化确实产生 `partialUpdate`，显式保存确实产生 `saveOrUpdate`；失败时不显示成功，也不自动重发结果未知的写入。
- [ ] **Step 4:** 运行适配层测试、`pnpm --dir canvas-app build`、根 `npm run typecheck` 和 `npm test`；提交集中适配。在桌面网络面板确认首版读写请求只经过 `/desktop-canvas/api/legacy/`，未向旧 Web Gateway 直接发送业务请求。

### Task 6: 桌面闭环、封包和差异记录

**Files:** Modify `docs/roadmap.md`, `docs/porting.md`, `canvas-app/PORTING-MANIFEST.md` for actual results; modify UI/Host files only for reproduced blocking defect.

**Interfaces:** 由桌面客户端当前登录态读取和保存测试画布。仍从现有 `dsh-resource://canvas/<id>` 标签进入，现有节点到 Harness 草稿消息不回归。

- [ ] **Step 1:** 在隔离 Profile 运行 `npm run build`、`npm run verify:isolated`、`npm run pack:plugin`；检查归档可安装、卸载，且不需要运行/安装旧 Web。记录包大小和静态资源 404/CSP/控制台错误。
- [ ] **Step 2:** 用可编辑的测试画布执行：打开 → 确认节点和连线 → 移动或修改一个节点 → 观察 `partialUpdate` 成功和版本号前进 → 显式保存 → 关闭右栏画布并重开 → 对照节点值/位置仍存在。再选节点，确认文字进入当前 Harness 草稿。每步记录画布 ID、请求路径、状态和结果，不记录 Token/完整图。
- [ ] **Step 3:** 用登录失效、无权限 ID、保存版本冲突分别检查页面提示与数据保持；无需为了首版测试跨标签并发写入。生产画布 `7607` 仅做只读启动核对，写入使用服务端授权的测试画布。
- [ ] **Step 4:** 修复实际复现的阻断问题后只重测相关路径；更新来源清单中的接入差异、最终依赖/包体积和首版未开放入口；`git diff --check` 后提交验收记录。若第 2 步未通过，阶段 2 不标记完成。

## 自检

- 方案的源码独立、三产物单包、真实登录态、读写与重开验收分别由任务 1–6 覆盖。
- 旧画布自动部分更新与显式保存都是首版验收项；SSE 和多标签细节没有被偷渡成前置工程。
- 服务器只需配合确认现有 get/partialUpdate/saveOrUpdate 在测试账号下的权限、版本冲突和测试数据；尚未研发的 subscribe 不阻挡此计划。
- 计划文档本身不执行旧源码复制；实际迁入启动时先复核来源提交与接口清单。
