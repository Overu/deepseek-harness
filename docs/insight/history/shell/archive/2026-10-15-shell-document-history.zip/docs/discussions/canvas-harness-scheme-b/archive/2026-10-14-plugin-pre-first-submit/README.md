# Desktop Canvas Plugin

独立的生产画布插件仓库，复用成熟 React Flow 画布业务与实时保存。0.3.0-alpha.17向Agent提供八个工具：创建、读取、普通节点编辑、素材引用/导入、真实连线、模型配置查询，以及普通图片/视频节点单点生成。操作由插件常驻Client服务中的原生Store、保存队列与监控执行，无需打开画布；生成进度与本次产物经Core Jobs回到原对话。后端与原生UI行为保持；模板、整图和工具节点生成尚未开放。用户已报告alpha.15实账画布素材生成成功；用户已报告alpha.16成果入口在真实客户端展示；alpha.17宫格布局与导航仍需真实账号手测，自动化fixtures不替代实账证明。插件随客户端登录环境选择服务，本地Dev走测试Gateway，正式安装版走生产。

[架构设计](docs/plans/2026-09-29-desktop-canvas-plugin-design.md) · [数据传输规范](docs/protocol.md) · [迁入清单](canvas-app/PORTING-MANIFEST.md) · [桌面验收步骤](docs/acceptance.md)

```sh
npm ci
pnpm --dir canvas-app install --frozen-lockfile
npm test
npm run typecheck
npm run pack:plugin
npm run verify:isolated
```

使用 Node.js >=22.12.0（仓库 `.nvmrc` 为 22.21.1）和 pnpm 11.7.0。插件通过 `dsh-resource://canvas/<十进制画布ID>` 定位标签。`canvas-app` 在独立构建中使用复制后的源码，不读取旧 Web 项目；根包只封入 Vite 产物、Host 和 Client。原 `canvas_get` 默认摘要输出及节点摘要 API 保留；view:nodes返回原生节点详情/版本，refresh:true显式重载。

隔离验收读取同级 Shell 的已构建运行时和 Profile 模板，在本仓库 `.sandbox/` 副本安装插件，不修改 Shell/Core 工作区。2026-09-29 的隔离安装/卸载、受保护页面和打包资源验证已通过。隔离 Profile 没有桌面登录态；本版真实编辑器的桌面人工验收结果见 [验收记录](docs/acceptance.md)。

## 工具契约维护

八个工具的名称、文案、超时和入参声明统一维护在 [canvas-tool-contracts.ts](src/shared/canvas-tool-contracts.ts)，采用现有 Harness ParameterSchemaSpec 数据格式，共用字符串输出 Schema。四个 Host 注册器引用声明，保留各自的校验、execute 和 renderer；业务 DTO/parser、v4 服务桥、Client 原生 Store 和保存队列各自负责其边界。该模块随插件构建，不单独发布，不负责运行时调用。

[test/canvas-tool-contracts.test.mjs](test/canvas-tool-contracts.test.mjs) 将实际注册目录与抽取前 alpha.13 的固定 fixture 比较，同时检查字符串渲染和模块无运行时依赖。纯重构不得更新 fixture 来消除差异；未来有意改变公开行为时，应明确兼容影响并同步评审声明、fixture、运行时校验和行为测试，不从当前声明自动生成测试期望值。

## Agent对话工具（0.3.0-alpha.17）

目标Core为0.2.1-alpha.1，工具peer要求该精确版本；开发dsh-tools与Cordis对齐实际Core的0.2.1-alpha.1 / 4.0.5-alpha.1。不宣称新工具已兼容旧Core0.1.6。新增附件peer要求0.2.1-alpha.1。开发Client/Host SDK与实际Core统一至0.2.1-alpha.1，解决旧开发包Cordis peer冲突；Web业务依赖不升级。Host运行依赖ali-oss6.20.0，与原Web同版本。

- canvas_create({name?})：Host复用固定saveOrUpdate创建空图，返回真实ID/address/version及runtime:ready或not_ready。创建成功但服务未就绪时保留ID；create_unknown不自动重建。
- canvas_get({canvasId,view?,nodeIds?,refresh?,nodeOffset?,edgeOffset?,limit?,expectedVersion?})：默认summary保持旧输出；nodes读取最多20个节点详情；graph读取真实节点、尺寸、端口、允许输入与边，每类独立分页1–20项。graph续页必须带第一页confirmed版本；版本变化重读第一页。refresh:true仅用于读取的权威重载。
- canvas_node_edit({canvasId,expectedVersion,action,...})：add添加普通text/image/video/audio；update用nodeId/changes改title/text/prompt/标量params；delete用nodeIds删除普通节点并清理原生关联边/空组；configure用nodeId/configuration配置普通image/video的modelType/model/标量params。各分支字段独立，不能提交原始node.data。上传或工具产物媒体仅改标题、删除，不改内容/生成参数。模型切换与级联参数优先用configure；先查询合法值。saved才表示保存，affectedEdgeIds返回真实边ID，warnings仅提示输入兼容性，不表示执行生成。
- canvas_edges({canvasId,expectedVersion,action,...})：add(connection)、delete(edgeIds)、reconnect(edgeId/connection)、reorder(targetNodeId/完整edgeIds)。source/target为真实节点ID，省略handles由插件解析真实原生端口。允许普通节点来源连接合法目标及已有工具输入；工具本体来源和内部产物管理边不开放。重复引用、假端口、新环及容量超限拒绝；reconnect保留ID，reorder只替换目标入边槽位。delete/reorder一次1–20个边ID。
- canvas_models({canvasId,nodeType,modelType?,model?,modeOffset?,modelOffset?,limit?,expectedCatalogVersion?})：只读当前账号图片/视频模型目录。返回真实value和可编辑标量参数；模式/模型独立分页，续页绑定catalogVersion。paramHints按所选模型默认父参数组合；配置后用nodes详情查询当前实时选项。不开放高级嵌套参数。

- canvas_assets({})：列出当前可见用户消息中的图片attachmentId/尺寸等信息，最多20条；无图片返回needs_input，不读其他会话/文件路径。
- canvas_asset_import({canvasId,expectedVersion,source,title?,placement?})：source为attachment+attachmentId，或canvas_node+canvasId/nodeId/outputIndex。Host使用当前用户STS/OSS上传或复用已授权节点产物，经v3桥asset.add保存原生图片来源节点；saved保留真实节点ID/版本，assetRegistration独立报告登记结果。

坐标契约：两类新增默认省略placement或使用{mode:'auto'}，由插件按最新Store及原生显示尺寸向右追加，既有节点不移动。精确位置使用{mode:'absolute',position:{x,y}}，包括(0,0)，不避让。沿已有节点延展使用{mode:'after',anchorNodeId}，按锚点世界位置右侧追加，不扫描全图、不建立连线，也不保证无局部重叠。模型工具不再接受裸position；共享协议/旧内部调用仍保留其精确含义。节点详情返回本地position、显示size、parentId（顶层null）；有parentId时坐标相对父组。尺寸读取失败时沿用原生默认占位，后续尺寸变化不自动重排旧图。

七工具保留JSON字符串输出。会话和内部requestId来自真实exec.agent.id/callId，不开放给模型；创建去重限定Host插件生命周期，节点和连线去重复用现有桥。每次写入使用最新confirmed版本，普通写前和写后使用refresh:false即可；refresh:true只用于显式权威同步或冲突/未知回执恢复，会重载可见画布，首次调用无需预先打开画布。模型配置请求失败时，已确认图的普通编辑与上传素材导入仍可保存；模型目录、生成节点新增及技术配置继续受配置门控。已有保存/版本不确定性时，配置失败不解除原有保护。用户要求失败停止时，参数校验失败/rejected也要停止，不能因为effect:none或error.retry而换source/参数自动续试；submission_unknown保留真实节点/边ID，先权威读取核对，不能自动重复写。关闭客户端/重启后不承诺跨进程exactly-once。原UI与dsh-resource地址保留，工具不自动打开标签。

素材说明：只支持Harness当前可见用户图片（PNG/JPEG/WEBP/GIF、小于20MiB），上传已归一化字节，可能压缩/修正朝向，不承诺原文件字节保真。文件附件及已被会话压缩移除的旧图需重新提供图片或明确既有画布节点。多产物来源需明确序号，不能自动猜选。已确认上传按环境/账号/会话/附件复用；unknown上传或保存不能换调用自动重试。保存成功但登记失败保留节点，不回滚/重复添加。

当前Agent可编辑真实业务图、节点和合法生成配置，并通过canvas_run执行普通图片/视频生成。节点编辑和素材导入仍只保存，生成由独立入口触发。原生图像编辑/抠图等工具业务已有，当前版本尚未开放创建工具节点或模板执行。能力未接入不能据此推断原生业务不存在。后端与原生UI入口保持现状；Agent不需要打开画布。

## alpha.15 对话生成

`canvas_run({canvasId,nodeId,expectedVersion})` 提交已有普通 image/video 节点，参数从最新 confirmed 读取取得。先校验输入、模型、权限和动态报价；复用原生容量检查与队列内版本、数量、编辑保护。生成只执行指定目标，连接的上游必须已有素材；不会运行未准备的上游或整个模板。

submitted 表示真实接受，返回 workflow taskId、版本及 jobId，尚不是生成完成。Core job_output(wait:true) 与完成通知提供真实阶段和本次 outputs；工作流与节点任务 ID 分别保留。旧产物、整图 SUCCESS 或 UI 本地监控异常不会被冒充本次结果。未知提交不自动重发，job_kill 只停止跟踪，不保证云端生成取消。

内部服务桥升级为 v4；升级插件后重启 Harness 并使用新对话，旧 Client 明确要求重新加载。SSE 仍负责命令下发，Client 沿现有 POST 上报回执和运行状态；Agent 无需周期轮询。关闭画布视图或切换对话不停止生成跟踪。完整退出客户端后进程内 Jobs/记录销毁，本阶段不承诺重启后自动恢复原对话通知；可权威读取节点事实，不能自动重新生成。

普通小规模生成不增加付费确认。同一真实用户需求累计超过 30 张图片或 6 条视频前，通过真实用户问题确认；公开参数不提供 confirmed/approvedGeneration。当前单节点接口没有整批计划的提前预批准。最多 8 个活跃跟踪任务，派发前预留状态空间，超限在生成执行前拒绝。


## alpha.16 画布成果入口

本版不改Core业务代码或后端，八工具契约保持。Plugin从本次可信原生完成/部分完成状态登记会话、原始根调用/Turn、画布、节点、运行与产物身份，复用官方Storage Domain持久化。已保存的来源通过受保护查询与SSE恢复到原始对话的独立成果区，提供“打开画布”和“定位节点”。不依赖Agent下载、命名、总结或读取job_output。

仅本版起成功登记的画布生成产物显示入口；普通文件、上传附件、非画布素材、空/未知结果没有入口，旧素材不猜测补绑，fork不自动继承父会话来源。现有本地文件卡片、系统打开菜单和预览保持。成果区展示真实产物数量，不另建播放器；临时URL过期不影响画布/节点定位。

Client复用conversation.chat.turnTail和SidebarRight.openResource；同一canonical画布地址复用Tab，通过params传nodeId。视图握手检查同源/父窗口/画布/view/channel，等待原生视图与节点测量后原生fitView，只临时高亮；不改变节点内容、选择、输入草稿、主图或保存版本。来源节点已删时打开原画布并准确提示，不创建替代节点或再生成。

来源保存失败只影响入口并记录诊断，不改变已发生的生成结果或自动重试模型；关闭Plugin等待已接收来源写入，关闭视图/切换对话释放展示订阅，不取消原生生成。重启恢复的是已确认并持久化的来源，不承诺恢复退出前尚未完成的生成跟踪。

目标运行时保持Core0.2.1-alpha.1；新增同版官方Storage/Session Query/UI类型依赖，来源schema的Zod4.6.5对齐当前Shell runtime。


## alpha.17 紧凑成果宫格与正式入口

复用alpha.16可信来源、持久化与原轮次归属，每个画布成果区使用真实画布名称和唯一“打开画布”按钮，不显示素材标题、画布编号前缀或张数。最多预览本轮生成的四个产物；一项真实产物打开并定位节点，多个产物仅打开画布。导航依据完整产物列表，不因只展示四项而改变。同节点生成多个产物也按多项处理，不把节点数量当图片数量。

外框按标题/按钮及图片实际占用宽度包裹内容，不撑满对话。图片与视频使用160px方形预览框，等比完整显示，不裁切或拉伸；四项空间足够时一排，不足时2+2，三项为一排或2+1，极窄空间退为单列并缩小方框。标题超过240px或可用空间时省略，悬停保留完整标题。视频只读取预览元信息，不自动播放，不另建播放器。预览失败显示占位，打开画布能力保留。

真实名称复用受保护的 `GET /desktop-canvas/api/snapshot?id=...`，只读现有后端get，不初始化业务上下文或模型目录、不打开画布。并发名称读取合并，组件再次挂载重新读取以支持改名；连接重置或插件卸载取消旧读取。读不到名称时以画布ID保底，既有临时素材URL失效时不猜测补绑、不重新生成。

原测试用“画布ID输入框 + 打开画布”控件已移除。保留不可见的Session通信挂载，因此Agent仍无需打开画布即可调用八个工具；正式打开途径为成果卡片或现有资源链接。Core、后端、源数据schema、原生画布UI和普通文件卡片均未改动。
