# Desktop Canvas Plugin 设计

> 2026-09-29 范围调整：首个真实业务闭环改为“加载已有画布、编辑、保存、重开确认”。SSE 和完整多标签行为不再是前置条件。[插件侧接入准备](2026-09-29-plugin-side-readiness-design.md)已完成；旧画布已做只读依赖调查，迁入尚未实施，详见[迁入设计](2026-09-29-canvas-source-port-design.md)。

## 目标与边界

本仓库是独立的 `@insight-ai/desktop-canvas-plugin`。插件随桌面安装包交付，在 Harness 右栏按画布 ID 打开标签；一个对话可以切换多张画布。Harness 工具调用画布服务，画布页面可将选中节点的信息送入当前对话输入区。`insight-web-platform` 只作为一次性源码来源；迁入后两个仓库不共享代码、依赖、构建或后续更新流程。

插件骨架、双向消息、当前客户端登录态与真实读取接口先作为接入基础验证。真实画布页面在获得迁入许可后接入，以加载、编辑、保存和重开确认作为首个业务闭环；事件流随后实现。Shell/Core 保持独立 upstream；插件开发期间不修改 Core，Shell 的预装接入只在独立工作树和分支进行。Demo 仓库保留为机制验证记录，不作为生产插件的运行时依赖。

## 方案选择

选择一个仓库、一个可卸载插件包、三个构建产物：Host、Harness Client、内置 Canvas Web。Host/Client 按 DSH 插件入口装载；Canvas Web 构建为静态资源，由插件 Host 提供给右栏 iframe。代码分别位于 `src/host`、`src/client`、`src/shared`、`canvas-app`，迁入旧画布后其业务源码只放在 `canvas-app`。

Harness Client 的 React 从宿主模块加载器取得；未来 Canvas Web 在 iframe 内自行打包其所需 React 版本，两个构建产物不共享 React 实例。

未选择双插件包：Host 与页面必须一同升级，拆包会增加版本配套和失配处理。未选择把旧 Web 工程原封不动打包：目标只有 `/canvas/$id`，整站路由、运营页面和发布配置会扩大维护面。实际迁入范围由构建依赖闭包决定；如果闭包很大，可以一次性复制必要目录和依赖，但仍在新仓库独立维护。

## 运行结构

```text
Harness 工具 ─┐
              ├─ 插件 Host ── 当前客户端登录凭据通道 ── 画布 Gateway/API
右栏 iframe ──┘       │                                  │
    │                 └─ 受保护的本机静态/API/SSE 路由 ←────┘
    └─ 版本化 postMessage ── 插件 Client ── 当前对话输入区

工具结果或对话产物 canvasId ── Client.openResource(dsh-resource://canvas/<id>)
```

Host 只允许配置中的测试或生产 Gateway 地址，所有远程请求从 Shell 私有进程通道按需取得当前登录 Token。Token 不写入插件磁盘、画布 iframe、URL、工具结果或日志。Host 的本机路由在读取文件或调用上游前使用 Core Connection 的 `requestRejection` 校验浏览器会话及 Host/Origin；画布服务仍按用户身份校验每个 ID 的读写权限。Demo 的 loopback-only 检查不能代替此校验。

iframe 将旧 Web 的脚本、样式和路由状态与 Harness 组件树分开；同源 iframe **不是安全隔离机制**。插件只装载本安装包内的受控静态资源，限制资源路径，设置页面 CSP，禁用非必要的顶层导航。若迁入的第三方代码要求更强隔离，另立专门源站与引导协议的设计任务，不在首个闭环中假定已实现。

## 数据与消息规范

`canvasId` 使用正 Long 的十进制字符串，不转成 JavaScript Number；节点 ID、任务 ID、产物 ID 分别保留原类型语义，不能混用。资源地址 `dsh-resource://canvas/<canvasId>` 是标签身份。所有修改类工具显式传入 `canvasId`；图像的可点击位置保存所属 `canvasId`，不能由图片 URL 推断。重复打开同一地址聚焦原标签，不同 ID 创建不同标签。

Host 对页面提供受保护的快照读取与订阅。订阅使用后端支持的 POST SSE，由 `fetch` 流逐块转发；事件只表示画布可能变化，页面在首次连接、重连、重新激活和有效变更通知后 GET 最新快照。快照以服务端版本和任务状态为准，过期响应不能覆盖较新状态；本地编辑待保存或冲突时不得直接覆盖草稿。只为当前可见画布保持订阅，标签卸载立即中止上游连接；隐藏后重新激活读取最新快照。心跳和检查点不等同于图数据。

页面发往 Client 的消息使用 `{ protocolVersion: 1, type, canvasId, requestId, payload }`。Client 校验 `event.origin`、`event.source`、消息版本、类型、ID 与载荷上限后，才把节点摘要加入当前对话草稿。Host 的工具结果返回结构化 `canvasId`、资源地址和必要的任务/产物关联字段；不会用文本解析或图片地址反推画布。跨页面消息和服务端 JSON 均视为不可信输入。

写命令必须区分“明确失败”和“响应丢失、结果未知”。Demo 证明后者可能已提交，不能自动重发创建或生成命令。服务端若实现请求 ID 去重，需约定保存期限、同 ID 不同参数的结果、查询结果接口及用户隔离；在此之前只允许读取重试，未知写入状态通过查询确认。

## 旧画布迁入原则

先记录旧仓库版本、文件清单、依赖和许可信息，再按 `/canvas/$id` 的构建依赖闭包一次性复制。保留画布的组件、状态、交互和业务算法，集中改动路由入口、API base URL/认证适配、静态资源路径及 Host 消息适配。旧 `useWorkflowTabGuard` 对多对话和标签卸载的行为要单独验证；不能让重新打开同一画布误判为失效。复制后不设置 submodule、workspace、alias 或构建脚本指向旧仓库。

## 发布与验收

每个阶段先在插件仓库构建 `.tgz` 并用隔离 Profile 验收。Shell 预装只消费固定版本和 SHA-256 的插件归档，安装、升级、卸载和用户移除策略单独测试；Shell 改动留在专用工作树/分支，不合并到主干，除非用户另行授权。真实服务联调必须在测试环境和正式客户端登录态下检查权限、Gateway 流式传输、多标签、离线恢复、生成结果和失败回退。

## 依据与未确认项

- Demo `07f09df` 已验证两张 SSE 连接互不干扰、关闭回收、重连回读，并暴露响应丢失后重复写入风险。它没有验证真实 Java SSE、Gateway 或完整画布编辑器。
- Core 当前右栏按资源地址去重；只渲染活动标签的内容，切换会卸载旧 iframe。因此活动标签需要重新读取快照，页面内临时编辑状态要与服务端保存语义协调。
- 附件《画布客户端接入：竞品分析与三种方案技术设计》提供 POST `/api/canvas/get` 和 POST `/api/canvas/subscribe` 的候选协议；其关于 Shell 内既有 `CanvasPanel` 的方案与本项目独立插件要求不一致，不作为本仓库实施前提。真实接口字段、权限、版本/任务通知、去重与网关超时由服务端联调确认。
- 服务端在本轮澄清：`subscribe` 仍处技术调研阶段，尚未研发。真实读取可以先验收；事件流必须等服务端交付协议和测试接口后联调。
