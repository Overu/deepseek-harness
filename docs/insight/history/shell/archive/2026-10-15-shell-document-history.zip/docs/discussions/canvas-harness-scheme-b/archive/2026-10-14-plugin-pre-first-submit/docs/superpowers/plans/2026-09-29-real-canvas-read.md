# Real Canvas Read Implementation Plan

> **For agentic workers:** Implement inline in the independent plugin repository. Do not change Shell, Core, Demo, or the legacy Web repository.

**Goal:** Read a real canvas using the desktop user's current login, expose a bounded node list to the embedded page, and give Harness a read-only tool whose result carries the matching sidebar address.

**Architecture:** The Host owns the Shell credential IPC and an allowlisted Gateway adapter. Both the protected local snapshot route and Harness tool call that adapter; neither sends the Token to the iframe or tool output. The browser page lists returned nodes and uses the existing versioned selection message.

**Tech Stack:** Node 22, DSH tools API, built-in fetch, Node test runner, existing esbuild package.

## Global Constraints

- Canvas ID is a positive signed-64-bit decimal string.
- Test/production Gateway origins derive only from `INSIGHT_DESKTOP_SERVICE_ENVIRONMENT`, never from the page request.
- Outbound request is POST `/game-ai-editor-center/api/canvas/get` with `{id}` and current desktop Token; redirects are rejected.
- A request failing before authentication must make no upstream network call. Do not persist or log the Token.
- User supplied an example response; its exact `data.data` encoding must be validated at the wire. No real credentials are available in the isolated Profile.

---

### Task 1: Desktop credential request and canvas response adapter

**Files:** Create `src/host/desktop-token.ts`, `src/host/canvas-get.ts`, `test/canvas-get.test.mjs`; modify `package.json` and lock file for `@deepseek-ai/dsh-tools`.

**Interfaces:** `desktopToken(): Promise<string>` requests a current Token over `insight:model-token:request`. `fetchCanvas(id: CanvasId, token: () => Promise<string>, transport?: typeof fetch): Promise<CanvasSnapshot>` returns `{ canvasId, name, nodes }` with bounded node summaries.

- [ ] Test parsing a valid `SUCCESS` response with `data.data` containing JSON text and rejecting malformed/error responses.
- [ ] Test that the adapter posts an ID string to the test Gateway, sets the Token header, and rejects redirects.
- [ ] Implement `desktopToken` with a unique request ID, one reply listener, 35-second timeout, and cleanup on reply/timeout.
- [ ] Implement the Gateway adapter with a fixed environment mapping, 15-second timeout, response size limit, and typed summary fields.
- [ ] Run `npm test` and `npm run typecheck`; commit the adapter.

### Task 2: Protected snapshot route and Harness read tool

**Files:** Create `src/host/snapshot-route.ts`; modify `src/host/index.ts`, `test/snapshot-route.test.mjs`.

**Interfaces:** `snapshotHandler(connection, fetcher)` serves GET `/desktop-canvas/api/snapshot?id=<canvasId>`. `canvas_get` tool requires explicit canvasId and returns an address plus bounded metadata.

- [ ] Test missing browser authentication returns 401 without calling the adapter; invalid ID returns 400; a valid request returns only the bounded response.
- [ ] Register the exact route through `ctx.effect`; call Core Connection `requestRejection` before parsing the request.
- [ ] Register `canvas_get` via `ctx.tools.register(defineTool(...))`; use the same adapter as the page route and include `dsh-resource://canvas/<id>` in the result.
- [ ] Run focused tests, typecheck, build and isolated Profile verifier; commit the route and tool.

### Task 3: Page uses real nodes

**Files:** Modify `canvas-app/app.js`, `canvas-app/index.html`, `README.md`, `scripts/verify-isolated.mjs`.

**Interfaces:** Page GETs `/desktop-canvas/api/snapshot?id=<canvasId>` on load, renders each summarized node as a button, and posts the selected node using protocol version 1.

- [ ] Replace the example node button with a loading state, error state, and real node buttons; keep text insertion user initiated.
- [ ] In isolated Profile, verify the protected API responds with a login error when Shell credentials are unavailable and that the static page still loads.
- [ ] Run `npm test`, `npm run typecheck`, `npm run pack:plugin`, and `npm run verify:isolated`.
- [ ] Commit. In a logged-in desktop app, manually verify test canvas 2873/2903 and a no-permission ID; record this as pending until actually executed.

## Exit check

The read-only tool and embedded page share one Gateway adapter. The isolated test proves packaging, authentication, request formation, and failure behavior without a live account. Real desktop login and Gateway response remain a separate integration gate. POST SSE and write commands are not included in this plan.

## 本轮结果

- `canvas_get` 工具与 `/desktop-canvas/api/snapshot` 共用真实 Gateway 读取适配器；页面仅显示至多前 100 个节点摘要，点击后才向当前草稿发送消息。
- `npm test` 11 项、`npm run typecheck`、打包及隔离 Profile 验证通过；隔离 Profile 中已确认未登录桌面时 snapshot 返回 401。
- 尚未在已登录桌面客户端调用真实测试画布，也未实测 Core 右栏标签点击和草稿写入。服务端已确认 POST SSE 尚未研发，因此本轮不实现 SSE。
