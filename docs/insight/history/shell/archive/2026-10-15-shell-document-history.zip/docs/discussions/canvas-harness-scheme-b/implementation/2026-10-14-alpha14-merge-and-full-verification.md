# alpha.14：契约分支合并与当前完整插件验收

用户授权合并 `codex/canvas-tool-contracts`，构建新版本并验证截至当前的完整插件。本轮快进合入原开发分支 `codex/desktop-canvas-plugin-init`，交付 **0.3.0-alpha.14** 独立包，保留 alpha.13 原包。没有推送远端、替换真实客户端安装或操作真实账号画布。

## 合并结果和源码边界

| 项目 | 实际结果 |
| --- | --- |
| 原开发分支起点 | `bd2a7b6` |
| alpha.13 工作区成果快照 | `7965b07` |
| 固定七工具兼容目录 | `04f002c` |
| 集中工具声明 | `a86115c` |
| 合并方式 | fast-forward，原分支落后 3 提交、没有独有提交，无冲突 |
| alpha.14 发布提交 | `864fc59f2cf0630820f8e8b5503b511c00d6396d` |
| 当前开发分支 | `codex/desktop-canvas-plugin-init` |
| 本轮新增改动 | 包及 lock 版本、README 当前版本，共 3 文件 |

快进包含此前任务成果的 alpha.13 快照，所以相对较旧原开发分支出现 116 文件的累计差异。**这不是本轮重新编写了这些业务。** 新契约开发相对 `7965b07` 仅涉及三处 Host 注册器、纯声明模块、固定兼容测试及 README；Client、v3 桥、原生 Store/队列、业务 parser、API、Web UI 执行逻辑没有因本次声明抽取改变。

七工具的 name、timeoutMs、description、ParameterSchemaSpec 及字符串输出 Schema 集中在 `src/shared/canvas-tool-contracts.ts`。三个 Host 注册器继续使用原 execute、校验顺序、错误和 renderer。冻结 fixture 来源于抽取前 alpha.13，未更新它来掩盖差异。纯声明模块与插件一起构建交付，不新增独立协议包、SDK、Zod、工具目录或第二套写入流程。

## 当前完整 Agent 接入能力

“完整”指下表所有**已经实现的接入能力**，不意味着原生画布全部业务均已开放给 Agent。

| 工具/底座 | 当前已实现范围 | 自动验收依据 |
| --- | --- | --- |
| canvas_create | 创建空画布，真实 ID/版本及服务就绪状态；失败保留已创建对象，不盲目重建 | API、Host 创建去重及完整注册工具链 |
| canvas_get | summary、nodes、graph；真实字段/端口/边、独立分页、confirmed 版本、显式权威刷新 | DTO/parser、图分页、冷刷新、完整工具链 |
| canvas_node_edit | 普通 text/image/video/audio 新增，字段修改，节点删除及关联边清理；image/video 合法模型配置 | 原生 factory、Store 严格保存、配置/尺寸测试 |
| canvas_assets | 当前对话可见图片附件引用，needs_input、多图绑定和会话边界 | 附件目录与素材工具测试 |
| canvas_asset_import | 聊天图片上传；既有图片节点产物复用；独立 upload 来源节点及独立登记结果 | Host → Client → Store fixture、一次 PUT、两种来源复用 |
| canvas_edges | 真实边新增/删除、改接保留边 ID、完整目标入边排序；真实端口及原生输入规则 | edge policy/Store、完整注册工具十次保存链 |
| canvas_models | 当前账号 image/video 模式、模型、合法标量参数、权限、目录版本和分页 | model policy、Host 工具、配置及级联测试 |
| 无界面服务 | Client 常驻 registry、冷上下文建立、关闭视图后可用；可见视图共用同一 Store | service/context、无 iframe 工具链、视图绑定 fixture |
| 原生保护 | 自动放置/精确坐标/锚点延展；队列内版本再校验、草稿防覆盖、保存回执、定向回滚、未知保存封写、原生所有权、鉴权撤销 | placement、guard、receipt、context 与原生 Store 测试 |
| 通信/构建 | Host HTTP + SSE、会话归属、去重和断线状态；服务 manifest/chunks、受保护路由、登录环境 | Bridge/Client tests、构建审计、隔离实际 Core 验收 |

上传及工具产物来源节点只允许改标题和删除，不能改写生成内容/参数。允许普通来源节点接到已有合法工具输入，不开放工具本体来源或内部产物管理边。`placement:after` 仅放置、不建边，不承诺全画布消除重叠。

公开生成执行、抠图工具节点创建、模板执行、批量 patch、完整业务 Skill 和任务5/6仍未开放。原生画布内部已有的业务不因未接入而不存在；内部 run 测试也不能证明公开 Agent 已有生成工具。

## 验证结果

| 验证层 | 结果及含义 |
| --- | --- |
| 插件全部测试 | **176/176 通过**，包含新增的 3 项契约兼容检查 |
| Web Agent 全部测试 | **276/276 通过**，22 文件 |
| Host 类型 | 通过 |
| 实际 Shell Core 类型 | 通过，目标 Core 0.2.1-alpha.1 |
| Web 类型 | 原有 **9** 项诊断，位置/错误码集合相同，无新增；未宣称全量 tsc 通过 |
| 独立审查 | 未发现阻断项；原 execute/parser/桥/Store 保持；冻结 23 份源哈希与抽取前提交一致 |
| Web/服务/Host/Client 构建 | 通过，服务静态依赖闭包审计通过 |
| 打包一致性 | 58 文件逐一与当前构建比较，无差异；alpha.13 包哈希保持 |
| 临时实际 Core | 七工具目录、认证/注册、SSE/会话同步/卸载、页面/API保护、服务资源安装卸载；结果见检查摘要 |

完整业务 fixture 串行验证节点修改/新增 → 两条真实边 → 模型查询/配置 → 排序 → 保 ID 改接 → 删边 → 删节点 → 权威回读，保存 10 次、生成调用 0、iframe 0。素材 fixture 验证冷态刷新、配置 502 降级、canvas_node 与附件独立复用、1 次 PUT/3 次保存、iframe 0。可见视图 fixture 验证三次编辑保持同一 Context/Store/Binding，readiness 不进入 loading。

这些是实际代码路径配合本地 API fixture 的自动验证；临时 Core 没有真实账号登录态，不能替代远端业务保存或真实窗口视觉验收。远端模型接口 502 未在本轮修复；健康已确认图的普通编辑/来源素材导入可降级继续，配置动作仍受真实可用配置约束。

## 包与使用

包：[insight-ai-desktop-canvas-plugin-0.3.0-alpha.14.tgz](/Users/boxser.shi/Documents/harness/desktop-canvas-plugin/insight-ai-desktop-canvas-plugin-0.3.0-alpha.14.tgz)。SHA、源提交、检查原始输出及当前账号边界见 [alpha.14 检查摘要](2026-10-14-alpha14-checks.json)。

本轮未安装到真实账号客户端，也未推送 Git 远端。要做实账复验时，导入此包、重启 Harness、新建对话，先核对实际启用版本与七工具目录。已有 103161 节点无需重复创建。

随后沿用 [三步修复复测](2026-10-14-alpha12-feedback-and-alpha13-fixes.md#三步短版复测)：R01 关闭画布后的冷读取、R02 可见视图连续编辑、R03 复用原图；prompt 中版本名称改为 alpha.14。再继续 [图编辑矩阵](2026-10-13-alpha12-copyable-prompts.md) P03/P04 和未完成的 P06–P10，使用当前真实节点名称、ID 和 confirmed 版本。对已完成项先读结果，避免重复新增、连线或删除。

参数校验失败/业务 rejected 与 unknown 按当次用户指令停步；effect:none 和 error.retry 不构成自动重试许可。实际首个 FRAME_NOT_READY 的原始参数仍未提供，已修复冷刷新缺陷但不宣称已证明实账报错的唯一根因。
