# 旧画布源码迁入设计

> 已确认方案：在 `desktop-canvas-plugin` 内建立独立的 Vite Canvas Web 子项目，一次性复制首版所需的旧画布源码和依赖，集中适配入口与请求。本文是迁入规划；不执行源码复制。首版验收范围为加载已有画布、基础编辑、保存、关闭后重开确认。生成、素材库、SSE 和完整多标签交互随后接入。

## 选择依据

当前插件已分别构建 Host 与 Harness Client，并把占位页面作为静态文件装入右栏 iframe。测试画布 `2873` 和生产画布 `7607` 已验证客户端登录态读取与页面到对话草稿的通信。现有 `canvas/get` 仅输出前 100 个节点的摘要，不能供真实编辑器还原图，也没有保存通道。

本轮只读检查的旧仓库为 `insight-web-platform` 的 `master`，提交 `28a2df99725b204f8f8d9fc5e240d7d368525d01`；**实际复制时必须重新冻结来源提交**。旧 `src/routes/Canvas.tsx` 是很薄的路由包装，业务集中在 `src/components/canvasFlow`，但该目录又引用 `src/api`、`src/store`、`src/routes/editor`、全局 Provider、样式及素材。静态导入扫描得到约 689/877 个 `src` 文件可达、约 77 个外部包名；这是保守的文件级估计，不能当作最终包体积。`AuthContext` 到整站路由表的引用明显扩大了可达范围。单独复制 `canvasFlow` 目录无法构建；整站原样复制会把登录、门户、发布配置和多 HTML 入口一起带进插件。

因此选择**独立 Vite 子项目 + 实测依赖闭包**：保留画布原有业务结构和状态/保存算法，在少数接缝上切断整站依赖。若闭包仍较大，首版接受真实必要的源码量，不为追求文件数而重写画布。

| 路径 | 适用性 | 决定 |
| --- | --- | --- |
| 把旧 Web 整站嵌入插件 | 搬运快，但维护无关页面、登录、构建和全站依赖 | 不采用 |
| 独立 Vite 子项目，按真实闭包一次性迁入 | 保留成熟画布逻辑，入口、认证和接口可集中收敛 | **采用** |
| 在 Shell/Core 中重写画布或拆成大量共享包 | 侵入 upstream，首版工期和回归范围过大 | 不采用 |

## 仓库与构建边界

继续使用**一个插件仓库、一个插件归档、三个产物**。根项目仍构建 DSH Host 和 React 18 Harness Client；`canvas-app` 拥有自己的 `package.json`、锁文件、Vite 配置及 React 19/Tailwind 4/Fabric/React Flow 依赖，输出 `canvas-app/dist`，由根包归档一起携带。iframe 内打包 React 19，不共享宿主的 React 实例。两层安装独立且锁定版本；初次迁入尽量以旧仓库锁文件解析出的版本为基线，删去经构建证明不需要的包。子项目可使用 pnpm 锁文件，根插件继续使用 npm，构建脚本明确顺序，不把旧仓库做成 workspace、submodule、alias 目标或运行时依赖。

```text
desktop-canvas-plugin/
  src/host/                 # 受保护的静态与 API 路由、当前客户端登录态
  src/client/               # 右栏 iframe 与现有节点消息桥
  canvas-app/
    package.json
    pnpm-lock.yaml
    vite.config.ts
    index.html              # 唯一 HTML 入口
    src/                    # 新的最薄挂载/接入代码
    legacy/
      src/                  # 一次性复制的旧画布源码，尽量保留原路径
      tailwind.config.js    # 若实际闭包需要，保留对应配置
    public/                 # 实际引用的静态素材
    dist/                   # Vite 构建结果；归档只带结果，不带源码/node_modules
```

从旧仓库冻结提交生成候选依赖图，再用单入口 Vite 构建、源码搜索和实际运行校正；`import()`、CSS、字体、图片、worker/wasm 和运行时拼接路径必须单独核查。只记录并复制首版实际需要的文件，保留原目录层次，避免批量改写 `@/` 导入。`@` 指向复制后的 `legacy/src`，集成入口从 `canvas-app/src` 引入画布。提交迁入清单：来源提交、复制文件列表及哈希、直接依赖版本/许可、各处有意改动和构建产物大小。清单是审计记录，不是每次构建从旧仓库拉代码的脚本。

Vite 只留单页面所需的 React、Tailwind、SVGR、Less、别名、worker/wasm 配置；旧多入口、版本更新门禁、浏览器兼容包、压缩和可视化插件不先继承。`base` 固定 `/desktop-canvas/`，Host 维持 `/desktop-canvas/view?id=...` 作为入口，并服务构建后带哈希的 JS/CSS/素材文件。Vite 会按 `base` 改写导入的资源和 CSS URL；运行时拼接的 URL 需逐项修正。旧 Tailwind CSS 的 `@config` 路径要与复制后的配置位置一致。此处依据 [Vite 构建文档](https://vite.dev/guide/build) 和 [Tailwind `@config` 文档](https://tailwindcss.com/docs/functions-and-directives)。

## 运行时接缝

```text
Harness Client 右栏标签
    └── /desktop-canvas/view?id=2873  ── iframe 内 Canvas Web
           ├── Vite 静态资源                 ← Host 受保护静态路由
           ├── 同源 /desktop-canvas/api/...   → Host → 固定 Gateway + 当前桌面 Token
           └── 节点选择 postMessage           → 现有 Client 校验 → 对话草稿
```

**页面入口。** 采用只包含 `/canvas/$id` 语义的最小路由环境，使原有 `useParams`、`useLocation`、`useNavigate` 可工作；按实际渲染需要提供 Query、主题、提示、对话框等 Provider。不要从旧 `App.tsx` 或整站 route table 启动。`useWorkflowTabGuard` 使用 `BroadcastChannel` 拒绝同 ID 的并发页；首版先在单画布内验证其行为，右栏切换会卸载 iframe，后续多标签阶段再确认是否需局部替换。若旧登录 Provider 引入整站路由，使用仅供画布的认证上下文接缝，不把旧登录页带入。

**服务请求。** 复制后的 `legacy/src/api/request.ts` 是集中改造点：保持旧业务调用方的 `request/get/post` 入口、请求参数与 `code/data/msg` 响应形状，让网络目标变为同源 `/desktop-canvas/api/...`。画布 Web 不读取桌面 Token，也不沿用旧 Web 的 localStorage/cookie、refresh 和跳 `/login` 逻辑；401 由 Host 返回“客户端需重新登录”的状态，编辑器显示可恢复错误。检查 `fullUrl`、上传、FormData、直接 `fetch` 等旁路调用；首版用到的必须纳入同一认证边界，未开放的旧入口显示不可用状态，不能暗中直连生产网关。

Host 每个路由先做现有 `connection.requestRejection` 校验。上游只允许配置过的测试/生产 Gateway、已列入首版的服务路径和 HTTP 方法，注入**当前**客户端凭据，并保留旧 API 的业务响应原文；不提供任意 URL 代理。首批候选请求来自真实画布挂载和编辑：`canvas/get`、`canvas/partialUpdate`、`canvas/saveOrUpdate`，以及挂载时的 `listNodeSetting`、`listModelNodeSetting`、`listToolNodeSetting`、`tone/list`、`cost/getAllRule`。执行时以网络记录校正最终清单；`VITE_MODEL_PARAMS_URL` 若实际启用也要经同源适配。响应体、请求体与耗时上限以真实画布大小和接口行为测量后定值，不能沿用摘要接口的 100 节点上限。

**保存语义。** 原 `flowStore` 维护 `versionNumber` 和保存队列；节点移动会触发 `partialUpdate`，显式保存走 `saveOrUpdate`。保留其冲突和序列化逻辑，不另造客户端版本规则。保存失败时必须显示原错误，不能让页面误报成功。写请求结果未知时先通过 `canvas/get` 核对状态，不自动重发可能已生效的写入。资源图和远端媒体仅按首版画布内容验证加载；若画布元素走第三方源，记录允许的来源与失败表现。

**静态资源。** Host 从插件归档中的 `dist` 服务文件，禁止目录穿越、符号链接逃逸与未列出的扩展；按 MIME 返回脚本、样式、图片、字体、wasm、worker 等资源。HTML 不缓存；哈希资源可缓存。页面 CSP 需要在真实资源清单上逐项放行 `worker-src`、图片/媒体/connect 等必要来源，不使用 `*` 放行或关闭 CSP。宿主已有前缀路由和 `/desktop-canvas/api/snapshot`，实施时应确认路由匹配优先级，避免静态路由吞掉 API。

## 交付顺序与验收

1. **冻结与测量（客户端）**：记录来源提交和闭包、运行时请求/资源列表、依赖与许可；产出迁入清单。验收：任何文件都可追溯来源，实际子项目不依赖旧仓库路径。
2. **Canvas Web 可构建（客户端）**：单入口、必要源码/依赖、最小 Provider 和路由，产出可由 Host 加载的 `dist`。验收：关闭旧 Web 开发服务器后，隔离安装包仍加载 JS/CSS/资源，控制台无入口错误。
3. **真实读写（客户端 + 服务端联调）**：Host 认证网关与集中请求适配；服务端确认测试账号对 `get/partialUpdate/saveOrUpdate` 的权限和版本冲突响应。验收：测试画布加载，移动或编辑一个节点，保存，关闭并重开，变更仍在；失败/登录失效有明确反馈。生产 `7607` 先只读检查，写入验收使用可编辑的测试画布。
4. **封包与回归（客户端）**：构建 `tgz` 并在隔离 Profile 安装，检查体积、资源路径、旧页面基础交互及页面→Harness 草稿。记录首版未开放的入口。验收：无需运行/安装旧 Web 项目；插件卸载后相关路由消失；Shell/Core 主干无本阶段代码改动。

SSE、生成/素材库等工具、多标签草稿和跨标签冲突策略均不阻塞上述闭环。首版保留必要业务模块的源码，并不意味着这些入口已完成产品验收；实际不可用入口要在界面上隐藏或给出明确提示。后续只在插件仓库维护，不自动同步旧 Web 新提交。

## 已知风险与处理

- **源码闭包大**：约 689 文件只是旧整站入口影响下的保守估算。先切断整站路由和旧认证，再看真实构建；不为了数字好看重构成熟业务模块。
- **画布宽度与旧页面布局**：右栏比原浏览器窗口窄。首版至少能查看、选中、编辑、保存；具体工具栏折叠或窗口尺寸问题以实测记录，不提前重写布局。
- **资源与上传旁路**：动态 URL、worker、文件上传可能绕开通用 request；逐项按首版功能验证，不能用“构建成功”代替运行验收。
- **多次写入与版本冲突**：沿用旧队列和服务端版本号；重开确认最终数据，失败不静默覆盖。不同标签并发编辑留到多标签阶段。
- **凭据与业务数据**：Host 路由按当前桌面用户鉴权；日志不输出 Token、完整画布图或敏感媒体 URL；不要把网关地址和 Token 注入 iframe 配置。
