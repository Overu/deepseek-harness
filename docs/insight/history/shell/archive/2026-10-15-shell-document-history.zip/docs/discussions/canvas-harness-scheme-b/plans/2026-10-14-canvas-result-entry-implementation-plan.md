# 插件画布成果入口实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. 当前会话未提供这两个技能，按用户已授权的“细化并开始研发”，使用现有 collaboration 分工、根 Agent 接线及独立 review，不再请求执行方式选择。

**Goal:** 对话内仅为真实画布生成产物提供“打开画布／定位节点”，来源持久化可在原对话历史中恢复，点击不保存或生成。

**Architecture:** 插件 Host 从原生 run 状态登记来源，使用官方 Domain 保存插件自己的记录；Client 通过受保护查询/SSE 获取，并通过现有 turnTail 插槽显示。导航复用 SidebarRight canonical 资源地址，插件 iframe 只读聚焦节点。Core 会话类型、present 格式、文件卡片和系统菜单不修改。

**Tech Stack:** TypeScript、Cordis Storage Domain/Session Query/Slots、React、现有 SSE 解码器、React Flow、Node test runner、Vitest。

## Global Constraints

- Core 和后端不改；Shell 只存计划/归档，业务实现集中在 Plugin。
- 复用原生生成、Store、保存队列、结果跟踪和资源导航；原生 UI、卡片预览、系统文件打开保持行为。
- 八个 Agent 工具的公开输入/输出不变，不新增模型可填写的素材来源、授权或会话字段。
- 只有可信 completed/failed 状态中已确认的本次新产物获得来源；上传素材、普通文件、旧节点产物、submitted/unknown 不冒充生成成果。
- 来源由 Host 运行执行点写入，不依赖 Agent 文案、文件名、任意 URL 或 job_output 首次读取。
- 不新增 SessionEventType，不修改 Core 持久格式；插件自己的记录有 schemaVersion。
- 来源记录失败不能改变已发生的模型生成事实或造成再提交。
- 初次/重连查询快照，后续 SSE 更新，不持续轮询。
- 本阶段支持原始会话历史恢复；不自动把父会话来源复制到 fork/新会话。
- canonical 地址仍为 dsh-resource://canvas/<id>，nodeId 放 params；定位只变视口/临时高亮。
- 旧插件包不可覆盖；构建新 alpha.16，不对真实账号主动提交生成。

## 共享来源与通信

```ts
interface CanvasResultBinding {
  sessionId: string; ownerId: string;
  rootCallId: string; callId: string;
  turn: number; rootCallSeq: number; sessionCreatedAt: number;
}
interface CanvasResultSource extends CanvasResultBinding {
  schemaVersion: 1;
  requestId: string; canvasId: string; nodeId: string;
  workflowTaskId?: string; nodeTaskId?: string;
  phase: 'completed' | 'failed'; version: string | null;
  generation: { images: number; videos: number };
  outputs: string[]; createdAt: number;
}
// 新私有来源 Store，不对模型暴露来源写入工具。
store.record(binding: CanvasResultBinding, state: CanvasRunState): Promise<void>;
store.subscribe(sessionId: string, listener: (source: CanvasResultSource) => void): () => void;
store.close(): Promise<void>;
```

Host 复用现有 session/event 观察根 tool/call 的 seq/turn，按真实 exec.rootCallId 捕获绑定，tool/result 后清除活动根调用索引；生成异步完成继续使用捕获的原始绑定。sessionId 来自真实 Session，ownerId 来自 Agent，不把桥路由标识当作 UI 会话身份。

只读路由为 `/desktop-canvas/api/results` 和 `/desktop-canvas/api/results/events`，参数 s 为真实会话、calls 为可选可见根调用 JSON 数组（默认会话单流，Client按各轮筛选），after 为分页游标。通过已有浏览器 connection 与 Session Query 授权/读取，校验根调用在该历史中的 seq、turn 与会话创建身份。SSE 首次/重连快照、落盘后的 upsert，分页上限100，调用筛选上限64；有限缓冲、断开释放订阅。不可把任意模型参数直接写成来源。

```ts
type ResultsEvent =
  | { type: 'snapshot'; sources: CanvasResultSource[]; nextCursor?: string }
  | { type: 'upsert'; source: CanvasResultSource };

// Client复用现有资源打开入口。
sidebarRight.openResource(canvasAddress(canvasId), { params: { nodeId } });
```

来源身份同时保留运行与原生任务信息，outputs 的序号只是本次结果顺序；点击历史产物定位其来源节点，不把旧产物设为当前主图。

## R1：可信来源及持久存储

**Files:** 新 shared/canvas-result-source.ts、host/canvas-result-store.ts；改 host/canvas-run-tools.ts；新增对应 Node 测试。

**Interfaces:** createCanvasResultStore(ctx) 装配官方 Domain；record(binding,state) 只接受内部可信状态；原生状态 requestId 原样保留 :run 后缀。

- [x] 新增并执行来源回归用例，验证以下关键断言：

  ```ts
  await store.record(binding, submittedState);
  assert.equal((await store.list(binding.sessionId)).sources.length, 0);
  await store.record(binding, completedState);
  await store.close();
  const restored = createCanvasResultStore(restoredContext);
  assert.equal((await restored.list(binding.sessionId)).sources[0].nodeId, completedState.nodeId);
  ```

- [x] 用官方 Domain 的表 put 和持久队列实现记录、同 request 幂等、恢复、查询/订阅/close；序号与状态验收均不能复用旧产物。
- [x] registerCanvasRunTools 接受内部 results writer，捕获真实根调用与会话；在可信终态回调登记，失败只记录来源故障，不改变 Jobs 终态，不重调 invoke。
- [x] 验证普通素材、空输出、无可信任务、不同会话、重复终态、快速完成、延迟到下一轮、持久失败/卸载收口。八工具冻结契约继续通过。

**验收目标：** 重启原会话有准确来源；Agent 没调用 job_output 也能登记；一次业务生成仍只 invoke 一次。

## R2：来源查询、推送与对话成果区

**Files:** 新 host/canvas-result-route.ts、client/canvas-results.ts、client/CanvasResults.tsx 和必要 locale；改 host/index.ts、client/index.tsx、package.json/锁；新对应 Node/Client 测试。

**Interfaces:** registerCanvasResultRoute(ctx,store) 提供上方只读查询/SSE；Client 解释既有根调用事件，把当前 turn/closing seq 与来源绑定；CanvasResults 通过现有 turnTail list 注册。

- [x] 验证未授权请求401/403、非当前会话/历史根调用不返回来源、分页和重连快照不漏记录，断开释放订阅；POST等方法不能写来源。
- [x] 加受保护 route；校验真实历史/root seq/turn/header身份，不用弃用 Session 快照读取，不加新会话事件。
- [x] 实现 Client 初始快照与 SSE 变更读取，按可见根调用筛选，重复快照/upsert不重复卡片；切换会话/卸载终止请求与重连任务。
- [x] 按画布分组显示真实图片/视频产物数、“打开画布”和“定位节点”；普通文件无记录时返回 null；不复制 Core 文件 UI/播放器，不扫描 DOM。
- [x] UI 与 Host 跨层用例：嵌套调用、异步跨轮、同轮多个画布、同节点重跑、原对话历史恢复、无来源、来源存储故障。

**验收目标：** 画布未打开也出现入口；非画布素材没有入口；原始轮次中结果及时更新，保持现有文件卡片行为。

## R3：只读节点定位

**Files:** 改 client/CanvasTab.tsx、canvas-app/src/desktop-canvas.tsx；新 shared/canvas-view-navigation.ts、canvas-app/src/canvas-view-navigation.tsx；新对应 Node/Web 测试。

**Interfaces:** SidebarRightResourceParamsMap.canvas 为 `{nodeId?:string}`；独立视图协议带 canvasId/viewId/channelId 和定位 request/revision，采用 ready/focus/result 握手，不混入 v4 Agent 保存/生成协议。

- [x] 验证 canonical URI 不变、重复导航有效、未 ready 排队、旧 channel/revision/result 不影响新目标。
- [x] Parent 校验 origin/source/画布/view身份；iframe 同样检查父窗口身份。只允许最后一次显式导航，视图重试有上限，业务请求次数不变。
- [x] 在 ReactFlowProvider 内挂载控制，等 viewport 和节点测量就绪、避免原生初始 fitView 动画覆盖，再用 fitView({nodes:[{id}],duration:0})；临时高亮不写 graph。
- [x] 验证组内节点、新开/已开画布、快速连续点击、节点被删、视图重载/关闭、无nodeId导航撤销；不改变选择、输入草稿、主图或保存版本。

**验收目标：** 一次点击到正确节点；同画布复用 Tab；整个定位过程零保存、零生成。

## R4：接线、review、发布及手测归档

**Files:** Plugin README、版本元数据、verify-isolated.mjs 必要检查；Shell 专项 implementation/evidence/README。

- [x] 根 Agent review各模块，再由独立Agent做整体review；修复本轮问题，不改现有 Web 类型诊断或其他业务。
- [x] 插件全部 Node/Web tests、默认与实际 Core runtime 类型、Web类型基线比较；保留必要失败修复证据。
- [x] 实际 Core 隔离 Profile 验证八工具、来源 Domain/路由/历史恢复、Client装配与定位打包资产；使用临时会话/fixture，不用生产账号生成。
- [x] 构建 alpha.16，核对包文件与源构建、SHA256；旧alpha.15包不覆盖，记录 Core工作区不变。
- [x] 归档实际接口与测试，提供产品角色朴素自然语言手测：一张图出现入口、打开并定位、重跑保留来源、视频、普通非画布素材无入口、重启恢复。

**验收目标：** 插件单独可发布，Core/后端无源码变更；自动验收与真实账号手测分开记录。

## 覆盖自检

可信来源、持久化、入口、定位分别对应R1–R3；依赖、生命周期、review、发布和手测对应R4。菜单首项、通用本地文件逐项绑定、复制会话来源自动继承、模板/工具节点未加入本阶段。


## 执行归档

R1–R4研发、必要修复、独立review、类型/回归、构建、包一致性和实际Core隔离验证已完成。来源观察与Jobs等待分开，未知/超时/停止等待后的可信晚完成仍能登记；使用现有isRunTrackingClosed与卸载清理，无业务重发。

插件251/Web330项通过，默认/实际Core类型通过；Web仍原9诊断。alpha.16包58文件与构建完全一致，Core及后端零改动。真实账号手测单独待验，见[用户手册](../implementation/2026-10-14-alpha16-manual-acceptance.md)。

- [ ] 用户真实账号验收：新生成图片入口、节点定位、原对话重启恢复、非画布素材无入口、视频及删除节点提示。

本地插件提交：`6aaac2783ffe0dc33995de50326019608a5f44cb`；未推送。
