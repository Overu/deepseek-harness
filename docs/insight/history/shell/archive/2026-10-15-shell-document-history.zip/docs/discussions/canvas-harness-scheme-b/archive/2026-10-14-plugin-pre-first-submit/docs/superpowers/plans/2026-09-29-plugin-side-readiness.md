# Plugin Side Readiness Implementation Plan

> **For agentic workers:** Execute the checked tasks inline in this independent plugin branch. Keep each task's test and commit together.

**Goal:** Make the existing read and iframe-to-composer bridge dependable before any old canvas source is moved.

**Architecture:** The Host keeps using the Shell private credential IPC and fixed Gateway. The Client keeps the existing validated `postMessage` route and Core's public `setDraft`; only request cancellation, node identity validation, and consecutive message draft handling change.

**Tech Stack:** TypeScript, React 18, Node 22 test runner, esbuild, DSH plugin SDK.

## Global Constraints

- Work only in `/Users/boxser.shi/Documents/harness/desktop-canvas-plugin` on `codex/desktop-canvas-plugin-init`.
- Do not read, modify, or copy old canvas business code. Do not change the plugin `canvas-app` placeholder this round.
- Do not modify Shell, Core, Demo, or their Git branches.
- Do not add SSE, save APIs, full graph proxies, or new UI controls before actual canvas source and server contracts are available.
- Keep Gateway and current desktop credential as the only remote identity path; never expose Token to iframe or logs.

---

### Task 1: Cancel credential lookup with the request

**Files:** Modify `src/host/desktop-token.ts`, `src/host/canvas-get.ts`; create `test/desktop-token.test.mjs`; modify `test/canvas-get.test.mjs`.

**Interfaces:** `desktopToken(signal?: AbortSignal): Promise<string>`; `fetchCanvas(id, tokenProvider?: (signal?: AbortSignal) => Promise<string>, transport?, signal?)`.

- [ ] Add a test that stubs the process IPC sender, starts `desktopToken(signal)`, aborts, checks an `AbortError`, and checks that the process `message` listener count returns to its initial value. A pre-aborted signal must send no IPC request.
- [ ] Run `node --import tsx --test test/desktop-token.test.mjs` and confirm failure on the current implementation.
- [ ] Add `signal?.throwIfAborted()` before IPC; register a one-shot abort listener and remove it in shared cleanup alongside the timer and message listener.
- [ ] Add a `fetchCanvas` test whose provider receives the same signal and resolves after abort; assert Gateway transport is never invoked. Pass signal to the provider and check it again after await.
- [ ] Run both focused tests and `npm run typecheck`; commit the source and tests.

### Task 2: Preserve node identity in the read summary

**Files:** Modify `src/host/canvas-get.ts`, `test/canvas-get.test.mjs`.

**Interfaces:** `parseCanvasGet(canvasId, body): CanvasSnapshot` continues returning exact valid node IDs; values exceeding the current 100-character iframe selection limit are rejected.

- [ ] Add a test with a 101-character node ID and assert `parseCanvasGet` throws a node-ID length error; keep the existing valid-ID test.
- [ ] Run `node --import tsx --test test/canvas-get.test.mjs` and confirm the new test fails because the current code truncates.
- [ ] Validate the ID bound before constructing the summary, then assign `id: node.id` with no slice.
- [ ] Run the focused test and typecheck; commit the two files.

### Task 3: Keep consecutive page selections in the composer

**Files:** Modify `src/client/CanvasTab.tsx`; optionally modify `test/message.test.mjs` only if a pure message behavior needs testing.

**Interfaces:** Keep the same `canvas.node.select` message and `InputActions.setDraft(text)` integration.

- [ ] Keep a `useRef` copy of the latest draft. Refresh it from `useInput` on render; when a valid selection arrives, compute `next` from the ref, set the ref to `next` immediately, then call `inputActions.setDraft(next)`.
- [ ] Keep origin/source/canvas validation and the existing summary text unchanged.
- [ ] Run `npm run typecheck`, `npm test`, `npm run build`, and `npm run verify:isolated`. Manually send two valid selection messages in one browser turn during desktop acceptance; expected draft contains the original text and both node summaries.
- [ ] Commit the Client change. Document the remaining Core `setDraft` versus simultaneous typing limitation in the release note if the manual acceptance cannot run here.

### Task 4: Align status documentation

**Files:** Modify `docs/roadmap.md` and `README.md` only where milestone status is currently misleading.

- [ ] State that the next real business acceptance is load, edit, save, and reopen; old canvas migration is awaiting explicit go-ahead. State that existing tests prove plugin mechanics, while authenticated Gateway and edit/save remain unverified.
- [ ] Check `git diff --check`, inspect the changed lines, then commit documentation.

## Self-review

- This plan covers the approved plugin-side preparation and leaves all old canvas business work untouched.
- It adds no server contract, package dependency, Shell/Core modification, or placeholder-page change.
- Automated tests cover cancellation and identity. The composer race needs an actual desktop interaction to prove end-to-end because the plugin has no DOM test harness; a passing build alone is not that proof.
