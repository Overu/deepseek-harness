# 画布素材的“查看来源画布”入口调研

状态：只读代码调研与建议，未编码，未修改插件/Core/Shell 业务。用户报告实账已按预期完成画布及素材，截图显示四个本地 JPG 文件卡片与系统打开应用菜单。本稿只讨论从成果回到制作画布的入口，不据截图推断具体画布 ID 或文件路径。

推荐路径已随用户新增的 Core upstream 合并／未来架构迁移约束修订，见[插件优先的成果入口方案](2026-10-14-canvas-result-entry-plugin-first.md)。本稿“完整目标需 Core 修改”指的是进入**现有通用文件卡片／菜单**的目标；从插件独立成果区打开来源画布可以复用当前扩展点，不必修改 Core。本稿保留为原菜单方案的范围分析。

## 结论

可以在菜单第一项增加“在画布中打开”，但这个菜单属于 Core 的通用文件 UI，需要 Core + 插件配合；无需改画布后端或生成 API。不要把画布伪装成 macOS 关联应用。

更推荐在有明确画布来源的素材卡片上直接显示“查看画布”或“定位节点”，并在同批素材区域提供一个整体“打开画布”入口。卡片点击主体继续预览图片/视频；系统默认打开与显示文件位置保留。菜单首项可以是第二入口。若当前希望仅发插件包、不升级 Core，则先提供插件自己的批次画布入口，不能称已改造现有文件菜单。

## 源码事实与改动归属

- Core `packages/client/ui-open-in-app/src/client/OpenTargetButton.tsx:119–131` 只渲染系统 applications 与 reveal，选择事件映射为 default/application/reveal，没有业务资源动作插槽。
- `packages/client/ui-open-in-app/src/client/FileRouteAction.tsx` 使用文件的授权 actionUrl 查询系统关联应用，并把选择送到原 native 文件打开回调。
- 文件卡片为 `packages/client/ui-deliverables/src/client/PresentedFileCard.tsx`，经 `Deliverables.tsx` 向 `deliverables.file.actions` 提供 actionUrl/available/pending/onAction；当前没有 file 或资源来源字段。
- `packages/deliverables/tool-present/src/types.ts` 的 PresentedFile 只有 path/description；`tool-present/src/index.ts` 只确认文件存在及权限后记入 deliverables/presented。文件卡片不能从这里知道 canvasId/nodeId。
- 插件 `src/host/canvas-run-tools.ts` 的 Jobs 结果具有 canvasId/nodeId/requestId/workflowTaskId/version/outputs，但不会下载本地文件或调用 present。截图中的本地命名、下载与文件交付属于后续 Agent 步骤；未核验该对话日志，不能假定其具体命令。
- 插件 `src/client/index.tsx` 已使用 `ctx.sidebarRight.openResource(canvasAddress(id))`。Core 的 openResource 已支持 params 与相同 canonical address 的 Tab 复用，可直接复用。

因此，真正缺少的是“本地交付文件 ↔ 可信画布产物”的来源关联，不能靠文件名、描述文案、当前选中画布或最近一次任务猜测。

## 三种交互

| 方案 | 用户操作 | 范围与判断 |
|---|---|---|
| 卡片显式“查看画布/定位节点”＋批次“打开画布” | 一次点击，入口直接可见 | 推荐完整目标；单素材来源需 Core 通用来源字段与 Slot，业务动作由插件注册 |
| 文件菜单第一项“在画布中打开” | 展开菜单再选择 | 可以实现；同样需要来源基础，还要扩 Core 的通用菜单动作。不建议唯一入口 |
| 插件独立的批次画布入口 | 在本轮结果区点“打开画布” | 低成本首步；复用 turnTail list Slot 和真实工具回执/插件持久事件，不修改 Core 文件卡片及菜单。无法单凭本地卡片定位其产物 |

布局建议：同一画布的四张图只显示一个批次入口，每张图保留更具体的“定位节点”；不同画布分开归属。按钮使用文字或带明确 tooltip/无障碍标签的图标，窄屏不挤掉文件名。不要更改全卡点击的既有预览行为。

## 必要的来源信息

Core 只认识通用资源来源，不写死 canvasId；例如持久化的交付元数据 `resourceOrigin` 包含 provider、address 与 params。画布插件拥有它的细节：

```json
{
  "provider": "@insight-ai/desktop-canvas-plugin",
  "address": "dsh-resource://canvas/103228",
  "params": { "nodeId": "真实节点ID", "outputIndex": 0, "runId": "真实运行引用" }
}
```

示例不是实账关联证据。来源必须由可信 Host 的导出/下载/交付步骤绑定到 owning session、实际文件及实际产物，再随交付事件持久化；不能仅让 Agent 任意填写一个地址。现有流程没有固定下载服务，故建议补插件内聚的交付适配器：只导出已有、已授权、已确认的素材，复用现有文件服务/交付，不重做生成，不任意下载用户 URL。具体是否新公开导出工具，属于下一次实施合同需要确认的接口选择，本轮未定为必需。

不支持可靠旧卡片回填时，旧文件继续保留原打开能力，不猜来源。内存 Map 不能作为唯一来源记录，否则重启/打开历史对话后入口消失。

## 文件拆分建议

以下为计划改动，不代表已改动。Core/Plugin 路径分别相对对应仓库。

### 通用来源及单素材入口（完整目标必需）

| 仓库／文件 | 职责 |
|---|---|
| Core `packages/deliverables/tool-present/src/types.ts` | PresentedFile 增加可选通用来源合同，旧 path/description 兼容 |
| Core `packages/deliverables/tool-present/src/index.ts` | 通过可信来源解析/登记补全来源，记入交付事件；输入/输出 schema 必要同步，不允许模型伪造资源归属 |
| Core `packages/client/ui-deliverables/src/presented.ts` | 来源数据读取及校验，旧记录兼容 |
| Core `packages/client/ui-deliverables/src/client/turn-deliverables.ts` | 确认来源随 turn 的交付元数据保留；现有 spread 能保留字段，是否需代码修改取决于合同 |
| Core `packages/client/ui-deliverables/src/client/file-actions.ts` | Slot 增加通用 file/source 上下文，不内置画布判断 |
| Core `packages/client/ui-deliverables/src/client/Deliverables.tsx` | 把当前文件及来源传给动作 Slot |
| Plugin 新增 `src/host/canvas-asset-delivery.ts` | 固化已有产物与本地交付的可信关联，集中处理来源与文件身份 |
| Plugin `src/host/canvas-run-tools.ts`、`src/shared/canvas-run-protocol.ts` | 复用现有运行身份/产物，必要时增加稳定产物引用；不改变生成方式 |
| Plugin 新增 `src/client/CanvasAssetActions.tsx`、修改 `src/client/index.tsx` | 根据已验证来源注册“查看画布”动作，调用既有 Sidebar API |

推荐用既有 file.actions Slot 添加插件按钮，不必为画布把 PresentedFileCard 重写。只有布局确实需要时再动 Core `PresentedFileCard.tsx`／`Deliverables.module.css`。

### 菜单第一项（选择菜单方案时追加）

- Core `packages/client/ui-open-in-app/src/client/OpenTargetButton.tsx`：增加通用 contextual actions，置于系统应用前，独立回调／分隔，不能转成 application id。
- Core `packages/client/ui-open-in-app/src/client/FileRouteAction.tsx`：把文件上下文动作接到共享按钮；文件/目录、preview header 的其他调用者保持兼容。
- Core `packages/client/ui-open-in-app/src/client/index.ts`：通用动作扩展接线；`locales.ts` 只添加通用文案，画布文案优先归插件。

### 打开后定位节点（可以独立分步）

- Plugin `src/client/CanvasTab.tsx`：读取 useTabNavigation 的 params/revision，把定位目标送到已登记 iframe。
- Plugin 新增 `src/shared/canvas-view-navigation.ts`：纯视图消息合同，canvasId/viewId/nodeId/request 身份、来源、大小及格式校验。
- Plugin 新增 `canvas-app/src/canvas-view-navigation.tsx`：等视图和节点测量就绪后，复用 XYFlow fitView 聚焦目标，临时高亮；重复点击仍可定位。
- Plugin `canvas-app/src/desktop-canvas.tsx`：在 CanvasSurface 的 ReactFlowProvider 内挂载定位控制。

保留 `dsh-resource://canvas/<id>` 为 Tab 身份，nodeId 放 navigation.params，不拼入地址制造同画布多个 iframe。原生 setFocusNodes/focusOnNodes 也存在，但直接使用局部 position、初始化时机可能过早；独立 fitView 控制更适合组内节点。

定位只改变视口和临时高亮，不调用 Store 更新节点、保存队列或生成 API。outputIndex 作为来源辅助信息；点击历史素材不能自动把该产物设为节点当前主图（原生切主图会保存），也不能把重跑后第 0 项误认作旧素材。

### Shell 与发布

Shell `src/main/index.ts`／系统文件打开逻辑无需加入画布业务判断。完整菜单或 file Slot 合同改动需要更新实际 Core runtime，再同步插件；Shell 使用锁定 runtime，发布时按现有流程更新 `core-runtime.lock.json` 或内测相应 lock 和 manifest。`scripts/prepare-core-runtime.mjs` 等脚本通常只执行，不必改逻辑。仅插件批次入口则可以只发布插件包。

## 开发顺序及验收

1. 固定交付来源：生成回执、实际导出文件和交付事件具有可靠关联，历史对话能恢复；新改名不按 basename 猜来源。
2. 复用 Sidebar 先打开正确画布：已打开复用原 Tab，未打开才挂载视图；不生成、不重载已就绪的 Context。
3. 加节点定位：等 ready/测量完成，组内节点正确定位；连续点击不同素材以最近一次明确导航为准。
4. 注册显式按钮；如选菜单，同时增加菜单首项。普通文件、系统默认应用、显示文件位置保持原行为。
5. 检查画布被删除、节点被删除、无权限、插件未启用、旧来源记录、多画布等失败路径：报告真实原因，不创建替代画布、不复制或重新生成素材。

自动/手测目标：一张图只导航到其真实来源；生成/保存请求计数为零；已有画布 Tab 不重复；重启后来源仍在；历史产物不被静默切换。这里不需要新的 Harness Agent 生成能力，只补交付来源和用户导航。
