import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { mkdir, writeFile, readFile } from 'node:fs/promises'
import { createServer } from 'node:http'
import { build } from '/Users/boxser.shi/Documents/harness/desktop-canvas-plugin/node_modules/esbuild/lib/main.js'
import { chromium } from '/Users/boxser.shi/Documents/harness/insight-harness-core/node_modules/.pnpm/playwright@1.61.1/node_modules/playwright/index.mjs'
const plugin='/Users/boxser.shi/Documents/harness/desktop-canvas-plugin'
const core='/Users/boxser.shi/Documents/harness/insight-harness-core'
const dir='/private/tmp/canvas-alpha17-gallery-browser'
const resolver=createRequire('/Users/boxser.shi/Documents/harness/insight-desktop-shell/package.json')
await mkdir(dir,{recursive:true})
await writeFile(dir+'/entry.tsx',`
import React from 'react'; import {createRoot} from 'react-dom/client';
import {CanvasResults,resultsZh} from '${plugin}/src/client/CanvasResults.tsx';
import {CanvasResultsStore} from '${plugin}/src/client/canvas-results.ts';
const cases=[1,2,3,4,6,'long','failed','video','unknown','verylong'];
window.galleryNavigations=[];window.galleryRequests=[];
const source=(id,count)=>({schemaVersion:1,sessionId:'case-'+id,ownerId:'owner',rootCallId:'root',callId:'nested',turn:2,rootCallSeq:10,sessionCreatedAt:100,requestId:'request-'+id,canvasId:String(2800+cases.indexOf(id)),nodeId:'node-'+id,nodeTaskId:'task',phase:'completed',version:'8',generation:{images:id==='video'?0:count,videos:id==='video'?1:0},outputs:Array.from({length:count},(_,i)=>location.origin+(id==='failed'?'/missing':id==='video'?'/clip.webm':i%2?'/portrait.svg':'/landscape.svg')),createdAt:200});
const store=new CanvasResultsStore({origin:location.origin,transport:async(input,init)=>{
 const url=new URL(input);window.galleryRequests.push({path:url.pathname,method:init?.method??'GET'});
 if(url.pathname.endsWith('/snapshot'))return new Response(JSON.stringify({canvasId:url.searchParams.get('id'),name:url.searchParams.get('id')==='2805'?'秋季耳机新品推广':url.searchParams.get('id')==='2809'?'这是一个非常非常长的画布名称用于验证标题截断及保留完整提示':'新品推广'}));
 const id=url.searchParams.get('s').replace('case-',''); const key=cases.find(value=>String(value)===id);const count=typeof key==='number'?key:1;
 const item=source(key,count);if(key==='unknown')item.generation={images:1,videos:1};
 return new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('data: '+JSON.stringify({type:'snapshot',sources:[item]})+'\\n\\n'));init.signal.addEventListener('abort',()=>{try{c.close()}catch{}},{once:true});}}),{headers:{'content-type':'text/event-stream'}});
}});
const t=(key,params={})=>Object.entries(params).reduce((value,[name,replacement])=>value.replace('{'+name+'}',String(replacement)),resultsZh[key]);
window.setGalleryWidth=width=>document.documentElement.style.setProperty('--fixture-width',width+'px');
createRoot(document.getElementById('root')).render(<>{cases.map(id=><div key={id} className="case" data-case={String(id)}><p>Fixture {String(id)}</p><CanvasResults turn={{turn:2,end:{seq:20},data:new Map([['desktop-canvas-results',{turn:2,calls:[{callId:'root',seq:10}]}]])}} seq={20} canvasResultsSessionId={'case-'+id} results={store} openCanvasResult={(canvasId,nodeId)=>window.galleryNavigations.push({canvasId,nodeId})} t={t}/></div>)}</>);
`)
await writeFile(dir+'/primitives.ts',`export {Button} from '${core}/packages/client/ui-primitives/src/Button.tsx'`)
await build({entryPoints:[dir+'/entry.tsx'],outfile:dir+'/bundle.js',bundle:true,format:'esm',jsx:'automatic',platform:'browser',plugins:[{name:'actual-public-button-and-shared-react',setup(b){b.onResolve({filter:/^@deepseek-ai\/dsh-client-ui-primitives$/},()=>({path:dir+'/primitives.ts'}));b.onResolve({filter:/^react(?:-dom)?(?:\/|$)/},args=>({path:resolver.resolve(args.path)}));}}]})
await writeFile(dir+'/index.html',`<!doctype html><meta charset="utf-8"><link rel="stylesheet" href="/bundle.css"><style>:root{--fixture-width:800px;--dsw-alias-label-primary:#eee;--dsw-alias-border-l3:#555;--dsw-radius-sm:6px;--dsw-alias-interactive-bg-hover:#292929}*{box-sizing:border-box}body{margin:24px;background:#151515;color:#eee;font:14px -apple-system,BlinkMacSystemFont,sans-serif}.case{width:var(--fixture-width);max-width:100%;margin-bottom:24px}.case p{color:#777;margin:8px 0}</style><div id="root"></div><script type="module" src="/bundle.js"></script>`)
const server=createServer(async(req,res)=>{
 const path=new URL(req.url,'http://localhost').pathname;
 if(path==='/missing'){res.writeHead(404);res.end();return}
 if(path.endsWith('.svg')){const landscape=path.includes('landscape');res.setHeader('content-type','image/svg+xml');res.end('<svg xmlns="http://www.w3.org/2000/svg" width="'+(landscape?640:180)+'" height="'+(landscape?180:640)+'"><rect width="100%" height="100%" fill="'+(landscape?'#bfd8ee':'#d3c4e6')+'"/><circle cx="'+(landscape?320:90)+'" cy="'+(landscape?90:320)+'" r="60" fill="white"/></svg>');return}
 try{res.setHeader('content-type',path.endsWith('.js')?'text/javascript':path.endsWith('.css')?'text/css':path.endsWith('.webm')?'video/webm':'text/html');res.end(await readFile(dir+(path==='/'?'/index.html':path)))}catch{res.writeHead(404);res.end()}
})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true})
const checks=[],errors=[]
try{
 const page=await browser.newPage({viewport:{width:1000,height:1100}})
 // Create a tiny local video fixture, independent of accounts or generated assets.
 const bytes=await page.evaluate(async()=>{const c=document.createElement('canvas');c.width=320;c.height=180;const ctx=c.getContext('2d');ctx.fillStyle='#7ea9bd';ctx.fillRect(0,0,320,180);const stream=c.captureStream(5);const chunks=[];const r=new MediaRecorder(stream,{mimeType:'video/webm'});const stopped=new Promise(resolve=>{r.ondataavailable=e=>chunks.push(e.data);r.onstop=resolve});r.start();const timer=setInterval(()=>{ctx.fillStyle='#7ea9bd';ctx.fillRect(0,0,320,180);ctx.fillStyle='white';ctx.fillRect(100,40,120,100)},40);await new Promise(resolve=>setTimeout(resolve,400));clearInterval(timer);r.stop();await stopped;stream.getTracks().forEach(track=>track.stop());return [...new Uint8Array(await new Blob(chunks).arrayBuffer())]})
 await writeFile(dir+'/clip.webm',Buffer.from(bytes))
 page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port)
 await page.waitForFunction(()=>document.querySelectorAll('[data-canvas-result-card]').length===10)
 const geometry=()=>page.evaluate(()=>[...document.querySelectorAll('.case')].map(root=>{const card=root.querySelector('[data-canvas-result-card]'),gallery=root.querySelector('[data-canvas-result-gallery]');return {id:root.dataset.case,available:root.getBoundingClientRect().width,card:card.getBoundingClientRect().width,buttons:card.querySelectorAll('button').length,title:card.querySelector('strong').textContent,columns:getComputedStyle(gallery).gridTemplateColumns.split(' ').length,tiles:[...card.querySelectorAll('[data-canvas-result-thumbnail]')].map(e=>({width:e.getBoundingClientRect().width,height:e.getBoundingClientRect().height})),titleClipped:card.querySelector('strong').scrollWidth>card.querySelector('strong').clientWidth,media:[...card.querySelectorAll('img,video')].map(e=>({width:e.getBoundingClientRect().width,height:e.getBoundingClientRect().height,fit:getComputedStyle(e).objectFit})),fits:card.scrollWidth<=card.clientWidth+1}}))
 const wide=await geometry();const by=(data,id)=>data.find(row=>row.id===String(id));
 assert.equal(by(wide,4).columns,4);assert.equal(by(wide,6).tiles.length,4);assert.equal(by(wide,1).card,182);assert.equal(by(wide,2).card,350);assert.equal(by(wide,4).card,686)
 assert(wide.every(row=>row.buttons===1&&row.fits&&row.tiles.every(tile=>Math.abs(tile.width-tile.height)<0.1)&&row.media.every(e=>Math.abs(e.width-e.height)<0.1&&e.fit==='contain')));assert.equal(by(wide,'long').titleClipped,false);assert.equal(by(wide,'verylong').titleClipped,true)
 await page.locator('[data-case="1"] button').click();await page.locator('[data-case="2"] button').click();await page.locator('[data-case="6"] button').click()
 const nav=await page.evaluate(()=>window.galleryNavigations);assert.equal(nav[0].nodeId,'node-1');assert.equal(nav[1].nodeId,undefined);assert.equal(nav[2].nodeId,undefined)
 const video=page.locator('[data-case="video"] video');await video.evaluate(e=>new Promise(resolve=>{if(e.readyState>=1)resolve();else e.addEventListener('loadedmetadata',resolve,{once:true})}));assert.equal(await video.evaluate(e=>e.paused&&!e.autoplay&&e.videoWidth===320),true)
 await page.waitForFunction(()=>document.querySelector('[data-case="failed"]').textContent.includes('预览不可用'))
 await page.screenshot({path:dir+'/wide.png',fullPage:true})
 await page.evaluate(()=>window.setGalleryWidth(400));await page.waitForFunction(()=>getComputedStyle(document.querySelector('[data-case="4"] [data-canvas-result-gallery]')).gridTemplateColumns.split(' ').length===2)
 const narrow=await geometry();assert.equal(by(narrow,4).columns,2);assert.equal(by(narrow,3).columns,2);assert.equal(by(narrow,4).card,350);assert(narrow.every(row=>row.fits&&row.tiles.every(tile=>Math.abs(tile.width-tile.height)<0.1)))
 await page.screenshot({path:dir+'/narrow.png',fullPage:true})
 await page.evaluate(()=>window.setGalleryWidth(140));await page.waitForFunction(()=>getComputedStyle(document.querySelector('[data-case="4"] [data-canvas-result-gallery]')).gridTemplateColumns.split(' ').length===1)
 const tiny=await geometry();assert(tiny.every(row=>row.card<=140&&row.fits&&row.tiles.every(tile=>Math.abs(tile.width-tile.height)<0.1)))
 const requests=await page.evaluate(()=>window.galleryRequests);assert(requests.every(item=>item.method==='GET'));assert.equal(errors.length,0)
 checks.push('Actual CanvasResults + official Button render','Real title, one button, snug 182/350/686px cards','All image/video frames square; proportional contain','4 wide, 2+2 and 2+1 narrow, one column at 140px','Four-preview cap and complete-count navigation','Single node focus; multi-output no node target','Local video metadata, paused/no autoplay','Image failure and unknown media placeholders','Long-title truncation, no container overflow','Read-only title/SSE fixture requests; no generation','No browser page errors')
 await writeFile(dir+'/checks.json',JSON.stringify({checks,wide,narrow,tiny,navigation:nav,errors,media:'local synthetic wide/portrait SVG and recorded WebM fixtures',coreBusinessChanges:0,backendChanges:0},null,2))
 console.log(JSON.stringify({passed:checks.length,checks,evidence:dir+'/checks.json'}))
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
