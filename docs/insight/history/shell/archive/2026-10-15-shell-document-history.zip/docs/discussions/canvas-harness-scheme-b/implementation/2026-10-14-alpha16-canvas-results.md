# alpha.16 插件画布成果入口实施与 Review

状态：研发、回归、类型、构建、独立 review 和实际 Core 隔离验证完成。真实账号成果区与 iframe 使用体验仍由用户按[手测步骤](2026-10-14-alpha16-manual-acceptance.md)确认；开发者本轮未安装用户的生产客户端、未提交真实模型生成。

## 交付能力

- 可信来源：从原生 run 完成/部分失败的新产物状态登记，保留会话、原始根调用/Turn、画布、节点、运行/原生任务及本次 outputs。没有新的 Agent 来源填写工具。
- 持久化：使用官方 Storage Domain 的版本化私有表，成功落盘后才发布入口；同运行去重，关闭等待已接收写入。坏记录按官方 per-record 机制备份跳过，正常来源仍能恢复。
- 对话入口：复用现有 conversation.chat.turnTail，按真实根调用和原始轮次筛选，按画布归组，展示真实图片/视频产物数与“打开画布／定位节点”。普通文件/附件没有入口；原文件菜单和预览保持。
- 节点定位：复用同一canonical画布Tab与navigation.params，经独立视图握手等待原生视口/节点测量，使用fitView聚焦及短暂DOM蓝框。不改节点、选择、草稿、主图或保存版本。
- 晚确认：来源观察独立于Jobs等待，非致命未知、超时或停止等待后仍接收可信原生完成结果。Jobs原终态保持；一次模型调用不变。

Core业务源码、Shell业务源码、后端均零改动；八工具公开合同保持。本版不追溯猜绑旧素材、不自动继承fork来源，不承诺恢复退出时尚未完成的任务。

## 文件及职责

Plugin根目录：`/Users/boxser.shi/Documents/harness/desktop-canvas-plugin`。

| 文件 | 职责 |
|---|---|
| src/shared/canvas-result-source.ts | 私有来源schemaVersion1、来源/快照/upsert读取校验与固定路由 |
| src/host/canvas-result-store.ts | 官方Domain的来源记录、去重、分页、订阅、持久关闭 |
| src/host/canvas-result-route.ts | connection鉴权、实际Session Query历史/根调用校验、只读快照和SSE |
| src/host/canvas-run-tools.ts | 捕获真实根调用与会话绑定；独立只读来源观察，保留Jobs/原生运行逻辑 |
| src/host/index.ts | 来源存储/路由/生成接线及官方服务依赖 |
| src/client/canvas-results.ts | 既有对话事件解释、原始轮次筛选、会话单SSE、分页重连、缓存清理 |
| src/client/CanvasResults.tsx | 插件成果区、官方Button及插件locale |
| src/client/index.tsx | 原始sessionId注入、turnTail挂载、连接重置与原有服务并行 |
| src/shared/canvas-view-navigation.ts | 纯视图hello/ready/focus/result协议 |
| src/client/canvas-view-navigation.ts | 最新导航、身份验证、有限视图消息重试与清理 |
| src/client/CanvasTab.tsx | navigation.params读取、iframe握手及缺失/不可定位提示；原节点选中回传保留 |
| canvas-app/src/canvas-view-navigation.tsx | ReactFlowProvider中的只读视口/临时DOM定位 |
| canvas-app/src/desktop-canvas.tsx | 只在绑定的插件视图挂载定位组件；Standalone保持原行为 |
| scripts/verify-isolated.mjs | 临时Profile真实官方存储/Session/路由/SSE夹具；不进入交付包 |
| package.json／package-lock.json、README.md | alpha.16、精确官方依赖和能力边界 |
| 5份新Plugin tests、已有run/service tests、agent-view-navigation.test.ts | 来源、官方Domain、HTTP/SSE、真实assembler、Client装配和实际ReactFlow回归 |

## 实际接口与流程

`CanvasResultBinding`：sessionId、ownerId、rootCallId、callId、turn、rootCallSeq、sessionCreatedAt。运行执行前从实际Session和同步tool/call事件捕获；PTC内部调用使用exec.rootCallId，不按最外层工具名判断。

`CanvasResultSource`：绑定字段＋schemaVersion:1、requestId、canvasId/nodeId、原生workflowTaskId/nodeTaskId、completed/failed、version、generation、outputs、createdAt。状态本身没有来源填写参数；无新outputs/原生任务身份不登记。

`createCanvasResultStore(ctx)` → record(binding,state)、list(sessionId,{after?,limit?,visible?})、subscribe(sessionId,listener)、close()。官方Domain承担写队列；每request只登记一次，record失败不改Job终态。

来源API：

- GET `/desktop-canvas/api/results?s=<sessionId>[&calls=<JSON根调用数组>][&after=<游标>]`。
- GET SSE `/desktop-canvas/api/results/events?s=<sessionId>[&calls=<JSON根调用数组>]`。
- 事件为 `{type:'snapshot',sources,nextCursor?}` 和 `{type:'upsert',source}`。

默认同会话单流，Client按各轮可见根调用筛选。初次/重连快照，分页100项并限制1MiB来源负载；可选calls最多64。Host通过官方observeSession(projectionMode:none)校验真实header创建身份、根调用seq/turn，每次落盘upsert重新验证当前历史，接纳后续新轮调用；不轮询。慢消费者有流数、待验证、消息和字节上限，断开后持久快照补齐。

UI使用`openResource(canvasAddress(id),{params:{nodeId}})`，地址不拼节点参数。纯视图协议检查origin/source/canvasId/viewId/channelId/request/revision；最新显式点击优先。iframe等待原生500ms初始化fit动画、测量和视口，再fitView duration0，DOM高亮1800ms。来源节点缺失只打开原画布并准确提示。

来源观察复用bridge.subscribeRun，在isRunTrackingClosed、明确rejected或Plugin卸载释放。同步终态回放时即便disposer尚未赋值也会收口；Jobs结束不关掉仍有可能完成的来源观察。原生成、报价、Store/队列、Client原生监控未重做。

## Review发现与修复

1. 确认私有Session事件存在恢复限制，使用独立Domain，未写任何新SessionEventType。
2. 单会话长连接初始历史cut不能永久复用，否则后续新轮产物被过滤；改为实际落盘事件触发重新校验。
3. 重连只追加快照会残留失效来源；完整分页后按快照seen＋同时期live记录清理，实时upsert优先，旧账号延迟页不能回填。
4. 独立UI类型缺少自动sessionId合并；按官方session-scope inject显式传真实sessionId，增加真实apply回归。
5. iframe ready可能早于onLoad；同channel不重复定位，真正新channel重载才重放目标，避免相同revision换request被拒绝。
6. 普通打开没有nodeId时不报定位超时；节点被删/隐藏/未测量保持真实提示且零业务写。
7. 实际Core运行时Zod为4.6.5，新增schema依赖对齐；用安全custom校验让损坏记录进入官方备份跳过流程。
8. 最终正文可能早于中断后工具完成；使用当前turn真实end.seq作为可见结束边界，不跨到未来调用/轮次。
9. 部分完成产物数量少于请求也标“部分产物”，不夸大实际数量。
10. Jobs未知/超时/kill后可能晚确认真实产物，来源不能依附已关闭的Jobs订阅；拆出来源观察并补三种晚完成回归。

独立review最终无未修复阻塞项，晚确认修复单独复审通过。

## 验证证据

- Plugin **251/251**，零失败/skip；其中run/source生命周期 **27/27**。
- Web **330/330**，26文件；含真实ReactFlowProvider挂载、组内绝对坐标定位和图/选择/草稿不变。
- 默认Plugin类型、实际Shell Core公开类型均通过。实际类型映射包含精确public subpath，避免只读开发包导致误判。
- Web既有**9**诊断逐行相同，无本轮新增；保留历史legacy问题，不顺手改业务。
- 实际Core隔离Profile：八工具、官方Domain持久化重开、真实Session历史/根调用、来源鉴权/查询/SSE、外root拒绝、服务桥与打包资源、安装/卸载通过；夹具没有实际模型调用。
- 实际Core浏览器：插件Client激活，官方UI Button依赖解析，零pageerror。浏览器测试候选的Client字节与最终包一致。此为装配smoke，不冒充完整真实账号成果卡片/iframe人工验收。
- 构建通过，仍有既有Vite大chunk警告；没有因本功能重构原Web。
- 安装包58文件逐项与构建一致，无probe/fixture/验收脚本，alpha.15原包SHA256保持。

完整机器摘要见[checks](2026-10-14-alpha16-checks.json)，证据在本目录evidence的alpha16文件。临时启动认证信息与原始私有日志没有归档，仅保留PASS摘要。

## 交付

包：`/Users/boxser.shi/Documents/harness/desktop-canvas-plugin/insight-ai-desktop-canvas-plugin-0.3.0-alpha.16.tgz`。

SHA256：`bb941e0b2fe24478e782c0e7caf66c68e9a86bc1296bd34a16e2a59adb12e124`，14,605,103 bytes。旧alpha.15保持14,478,591 bytes及原SHA256。未推送远端，未改生产账号。

已保存的画布来源可以重启恢复；退出时尚未确认产物的跟踪不承诺自动恢复。来源登记失败会记录诊断、入口缺席，但真实生成结果保持，绝不通过再生成来补入口。

本地插件提交：`6aaac2783ffe0dc33995de50326019608a5f44cb`，分支`codex/desktop-canvas-plugin-init`；插件工作区干净。Shell只更新本专项文档，保留此前文档改动。
