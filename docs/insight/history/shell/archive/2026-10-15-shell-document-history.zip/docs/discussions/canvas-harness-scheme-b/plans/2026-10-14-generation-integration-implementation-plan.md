# Agent 画布单节点生成实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. 本会话没有这两个技能，按用户已授权的“复审后执行”，使用现有 collaboration 子 Agent 分工并逐项验证，不另外等待实施选择。

**Goal:** 用户通过自然语言真正生成画布中的图片或视频，关闭画布视图后仍能跟踪，完成时原对话获得本次产物；支持改提示词后局部重跑。

**Architecture:** Host 工具负责对话归属、数量确认与 Core Jobs；常驻 Client 负责调用原生 Store 单节点执行及原有监控。新运行记录从可信后端观察识别本次节点任务，沿现有 SSE 命令与 POST 回执通路推送，复用 Core 的等待、结果读取和完成通知。

**Tech Stack:** TypeScript、React Flow、Zustand、Cordis、现有 Core Jobs/User Questions、现有 Workflow/Cost API、Node test runner、Vitest。

## Global Constraints

- 后端不改；不改变原生 UI 的生成、报价、保存与监控行为。
- 现有七工具的公开参数和返回形式保持兼容，增加独立 `canvas_run`，不混入节点保存操作。
- 本阶段仅普通 image/video 节点单点执行；上传素材、工具节点、模板及整图依赖执行不开放。
- Agent 不周期调用读取工具等待生成；复用 Client 原生监控及任务事件。
- 超过 30 张图片或 6 条视频才请求真实用户确认；同一需求累计，不能靠拆调用或模型字段绕过。
- 复用 1.1–1.4 的版本、编辑保护、Store、持久化队列、无 iframe 生命周期。
- 既有 alpha.13/alpha.14 包不可覆盖；本轮不对真实账号提交模型生成。
- 本地运行记录和 Jobs 均为进程内数据。关闭画布视图继续跟踪；完整退出客户端后，不承诺恢复原对话自动通知。重启后可权威读取已保存的节点事实，不能自动重新生成。

## 复审结论与结构

原生 `excuteSingle` 已提供模型调用、容量/输入检查、队列校验和 loading；仅放开 bridge 的 run 枚举会缺少动态报价、运行归属和自动回话。因此不新增执行引擎，补三个有明确边界的模块。

1. **原生预检与结果归属**：共享报价 helper、Agent 预检、Context 内 run tracker、monitor 的权威观察回调。
2. **通信**：内部服务协议 v4、run 能力、preflight 与 submitted 回执、任务快照事件、缓存重放与生命周期。
3. **对话入口**：一个 `canvas_run` 工具、调用去重、数量确认、Core Jobs producer。

`invoke.taskId` 与 `node.taskInfo.taskId` 分别保留。旧图片、整图 SUCCESS、本地监控错误后的 FAILURE 均不能证明本次任务成功或失败。没有足够关联证据时报告结果未确认，不冒用旧图。

## 共享接口

```ts
// 新增到 CanvasOperation；只读报价，不产生模型任务。
type PreflightOperation = {
  action: 'node.preflight'; expectedVersion: string; nodeId: string;
};
type RunPreflightReceipt = {
  status: 'preflight'; canvasId: string; version: string; nodeId: string;
  generation: { images: number; videos: number };
  quote: { points: number; originalPoints: number | null };
};

// 宿主可信 requestId 关联调用，不增加模型可写的批准字段。
type CanvasRunState = {
  requestId: string; canvasId: string; nodeId: string; sequence: number;
  phase: 'submitted' | 'running' | 'completed' | 'failed'
    | 'monitoring_unknown' | 'submission_unknown';
  version: string | null;
  workflowTaskId?: string; nodeTaskId?: string;
  generation: { images: number; videos: number };
  outputs: string[]; error?: Failure;
};

// CanvasExecuteInput 追加可选可信 requestId，端点在 node.run 时传入。
runtime.subscribeRun(
  input: { canvasId: string; expectedContextId: string; requestId: string },
  listener: (state: CanvasRunState) => void,
): () => void;
bridge.subscribeRun(
  target: BridgeTarget, requestId: string,
  listener: (state: CanvasRunState) => void,
): () => void;
```

新上行消息 `canvas.run.state` 携带 protocolVersion:4、connectionId/sessionId/canvasId/contextId/requestId/state。它必须匹配已登记的 node.run 命令及目标节点，序号单调；同序号相同内容允许重放，不同内容拒绝。运行订阅即时重放缓存；先订阅再执行，覆盖任务极快完成先于提交回执的情况。

## 任务 G1：原生预检、共享报价与运行归属

**Files:**
- Modify: `src/shared/canvas-agent-protocol.ts`：node.preflight 与严格回执校验。
- Create: `src/shared/canvas-run-protocol.ts`：运行快照及严格解析。
- Create: `canvas-app/legacy/src/components/canvasFlow/utils/workflowCost.ts`：报价副本与结果归一。
- Modify: `canvas-app/legacy/src/components/canvasFlow/hooks.ts`、`legacy/src/api/order.ts`：UI/Agent 共用报价，维持原有 UI query 行为。
- Create: `canvas-app/src/agent-run-preflight.ts`、`canvas-app/src/canvas-run-tracker.ts`。
- Modify: `canvas-app/src/agent-adapter.ts`、`canvas-context.ts`、`canvas-generation-monitor.ts`、必要的 `legacy/src/store/flowStoreCore.ts` strict 分支。
- Test: 新报价、tracker 测试及 `canvas-app/test/agent-runtime-complete.test.ts`。

**Interfaces:** tracker 提供 Context 级 `subscribeRun(requestId, listener)`；adapter.execute 的第三参数为可信 requestId。preflight 从原生 payload 得到真实数量及动态报价；node.run 的批准数量由 Host 派生，队列内再次核对。

- [x] 写并运行报价及 tracker 失败用例。关键断言：`normalizeWorkflowCost(NaN)` 抛错；原 payload 空 prompt 不被修改；旧 taskId/旧 URL 的 success 不产生 completed。
- [x] 提取报价 helper，只在成本请求副本填空格；number 与折扣对象校验有限非负数。UI 保留 enabled/retry/queryKey。
- [x] 加严格预检：权限、输入、可信版本、节点忙态、用户编辑保护、容量、动态报价。失败返回 effect:none，invoke 次数为 0。
- [x] 注册运行前快照，再执行原生 single；成功登记 workflowTaskId/accepted version；未知提交保留真实信息且不重发。
- [x] monitor 增加成功权威观察和监控异常回调。tracker 固定本次新节点 taskId 或可信本次运行关联；不以 URL 变化作为唯一证据。
- [x] 覆盖不同 workflow/node taskId、快速完成、旧终态、空产物、监控六次异常、auth/dispose、报价期间版本或草稿变化。原生本地 FAILURE 保留，对话收到 monitoring_unknown。

**目标/验收：** 复用原生 invoke 一次；前置失败零 invoke；本次真实产物可被识别，无法关联时不宣称成功；关闭 view 不停止 Context。

## 任务 G2：Host / Client / 常驻 Runtime 通路

**Files:**
- Modify: `src/shared/canvas-bridge-protocol.ts`、`canvas-service-runtime.ts`。
- Modify: `src/host/canvas-bridge.ts`、`bridge-route.ts`。
- Modify: `src/client/canvas-command-endpoint.ts`、`canvas-bridge.ts`、`canvas-service.ts`。
- Modify: `canvas-app/src/canvas-service.ts`。
- Test: bridge protocol/registry/route/endpoint/client 测试。

**Interfaces:** capability:run；node.preflight 为只读但需要 run 准备；node.run 允许 submitted/run unknown；运行事件按上方合同。

- [x] 新增协议测试：v4 接受 run 与 preflight；v3、错误 session/context/node、重复序号不同内容均拒绝。
- [x] 升级服务桥为 v4；iframe 原有协议不变。旧 Client 明确要求重新加载，不执行不支持的生成命令。
- [x] Host 在派发前登记订阅，Client 在 execute 前订阅 Context，信任端点传入 requestId。submitted 不被当成 saved。
- [x] 丢回执正确返回 phase:run、nodeId/generation；断线仅恢复事件，绝不重发模型任务。
- [x] 分离 ack 与 run.state 的 outbox key、控制缓存上限、同序号去重。完成可以先于 ack。
- [x] 活跃 run 订阅独立于当前聊天 UI 绑定，切换对话仍接受与旧 run 命令匹配的状态。解绑画布 view 不清除运行跟踪。

**目标/验收：** 没有 iframe 时，命令与新结果事件走通；重复同调用一次 invoke；切换 UI 和 SSE 重连不产生二次生成或丢失已缓存终态。

## 任务 G3：公开生成工具与 Core Jobs

**Files:**
- Create: `src/host/canvas-run-tools.ts`。
- Modify: `src/shared/canvas-tool-contracts.ts`、`src/host/index.ts`、`package.json` 和依赖锁。
- Test: `test/canvas-run-tools.test.mjs`；保留七工具冻结合同测试。

**Interfaces:** `canvas_run({canvasId,nodeId,expectedVersion})`；输出仍为 JSON 字符串，submitted/unknown 带 requestId/address/jobId 及真实提交信息。终态经 Core job_output(wait:true) 和 tool-jobs 完成通知获得，不另外创建重复等待工具。

```ts
registerCanvasRunTools(
  ctx: Context, bridge: CanvasHostBridge,
  options?: { imageTimeoutMs?: number; videoTimeoutMs?: number },
): void;

preflightCanvasNode(
  context: CanvasContext,
  operation: Extract<CanvasOperation, { action: 'node.preflight' }>,
  signal?: AbortSignal,
): Promise<RunPreflightReceipt>;
```

- [x] 工具测试覆盖：无 Jobs/controller、无真实用户确认、数量累计超限、busy、版本变化均零 invoke。
- [x] 提交前完成 Jobs admission；producer 使用独立执行生命周期，提交后停止工具等待不取消后端任务。
- [x] 根据可信 preflight 派生 approvedGeneration；公开 schema 不提供 confirmed/approvedGeneration/session/token 字段。
- [x] 按 session 最新真实用户消息归并数量，串行预算检查；超过 30/6 用 Core User Questions 真实答复。取消/无答复不提交，未知提交保留预算。
- [x] 同 call promise 去重；任务终态只交付一次。completed 返回本次 outputs；failed 保留实际错误；monitoring_unknown 明确“结果未确认”，不换方法重生成。
- [x] 复用 Core 完成通知，工具说明要求 Agent 展示新产物；使用现有 Jobs 查询真实阶段，不编造百分比。

**目标/验收：** 一句“生成这张图”无需手动 UI 点击；原对话能等待或自动接收新结果。Job kill 只停止跟踪，不能声称模型任务已取消。

## 任务 G4：整体验证、打包和产品验收

**Files:** `scripts/verify-isolated.mjs`、README、版本元数据；本专项 implementation/evidence 归档。

- [x] 完成最终 diff review，修复当前改动带来的问题；不顺手修复已有 Web 类型诊断。
- [x] 跑全部插件/Web 测试；Host 和实际 Core 类型检查；比较 Web 类型诊断与 alpha.14 基线。
- [x] 补通路 fixture：无 iframe 预检→提交→权威新任务结果→Jobs 输出；参考图和视频复用原生输入关系，不执行未准备的上游。
- [x] 构建新 alpha 包、核对内容和 SHA256；保留旧包；隔离 Profile 验证实际 Core 八工具目录、服务桥 v4、受保护路由及安装/卸载。
- [x] 保存实现/验证归档，给产品角色可复制的朴素验收 prompts。真实模型质量及 workflow/node taskId 关联最后由实账核验，不以 fixture 代替。

**主流程手测目标：** 不打开画布，先生成一张图片并在对话看到；浅蓝背景局部重跑得到本次新图；再单独生成一条短视频。运行期间询问状态不能多生成一份。再检查缺参考图、编辑中、网络断线和未知提交等细节。

## 覆盖复审

能力补充覆盖生成、报价、数量、原生校验、结果和自动回话；结构覆盖共享合同、Client 执行、Host Jobs；生命周期覆盖 view 关闭和对话切换。模板、抠图工具节点、全图执行、后端中断和跨客户端重启自动通知没有混入本阶段。代码/fixture 通过与真实账号通过分别记录。

## Execution status

G1-G4 development, review, automated tests, build and isolated Core verification complete. Plugin commit: 0f871ee1170ebdb565b188f2d4bce4e91f4ef991; release package: 0.3.0-alpha.15.

- [ ] Real-account acceptance: actual new image, local rerun, video and completion feedback in the owning dialogue. No production generation was submitted in this development run.

See [implementation and review](../implementation/2026-10-14-alpha15-generation-integration.md) and [product acceptance prompts](../implementation/2026-10-14-generation-manual-acceptance.md).
