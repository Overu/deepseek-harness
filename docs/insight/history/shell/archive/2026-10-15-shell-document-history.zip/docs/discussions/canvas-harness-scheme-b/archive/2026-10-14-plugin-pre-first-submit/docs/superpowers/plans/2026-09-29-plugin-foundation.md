# Desktop Canvas Plugin Foundation Implementation Plan

> **For agentic workers:** Implement inline in this independent repository, one task at a time, with a focused check and commit after each task. No subagent dispatch is authorized for this work.

**Goal:** Build a removable canvas plugin package whose protected static page opens by numeric canvas ID in the Harness right sidebar and can send a selected node summary to the current conversation draft.

**Architecture:** One npm package builds Host and Client entries plus an embedded static Canvas Web page. Host serves the page behind Core Connection browser authentication; Client owns tab registration and the versioned iframe message receiver. This foundation uses no remote canvas data or legacy Web source.

**Tech Stack:** Node 22, TypeScript, React 19, esbuild, DSH Cordis Host/Client plugin interfaces, Node test runner.

## Global Constraints

- Repository: `/Users/boxser.shi/Documents/harness/desktop-canvas-plugin`; branch `codex/desktop-canvas-plugin-init`.
- Do not modify Shell, Core, Demo, or `insight-web-platform` in this plan.
- No dependency or build path into the Demo or legacy Web repository.
- `canvasId` is a positive signed-64-bit decimal string; no JavaScript Number conversion.
- Every page route calls `ctx.connection.requestRejection` before reading assets.
- Do not call a real canvas service or expose a login Token in this foundation.

---

### Task 1: Package, build, and resource identity

**Files:** Create `package.json`, `package-lock.json`, `.gitignore`, `scripts/build.mjs`, `src/shared/protocol.ts`, `test/protocol.test.mjs`, `README.md`.

**Interfaces:** Export `parseCanvasId(value: unknown): CanvasId | undefined`, `canvasAddress(id: CanvasId): string`, and `canvasIdFromAddress(address: string): CanvasId | undefined` from `src/shared/protocol.ts`.

- [ ] Write `test/protocol.test.mjs` with `node:test` assertions that `2873` and `9223372036854775807` parse and `0`, `01`, `-1`, `9223372036854775808`, and a query-suffixed address fail.
- [ ] Run `npm test` and confirm the missing protocol module fails the test.
- [ ] Implement the three exports. Validate with `/^[1-9][0-9]*$/u` then `BigInt(value) <= 9223372036854775807n`; format addresses as `dsh-resource://canvas/${id}`.
- [ ] Set package name to `@insight-ai/desktop-canvas-plugin`, exact version `0.1.0`, Host export `./lib/index.js`, Client export `./lib/client.js`, DSH client injections for sidebar-right and slots, and package files `lib`, `canvas-app/dist`, `cordis.patch.yml`, `README.md`.
- [ ] Add an esbuild script that emits the Host ESM entry and wraps the Client CJS output with `window.__ModuleLoader__.load({ id: '@insight-ai/desktop-canvas-plugin', factory })`; bundle no code from sibling repositories.
- [ ] Run `npm test` and `npm run build`; confirm both pass. Commit Task 1.

### Task 2: Protected embedded page

**Files:** Create `src/host/index.ts`, `src/host/page-route.ts`, `canvas-app/index.html`, `canvas-app/app.js`, `test/page-route.test.mjs`, `cordis.patch.yml`.

**Interfaces:** `registerPageRoute(ctx: Context): void` registers a `/desktop-canvas` prefix route. `apply(ctx: Context)` in `src/host/index.ts` calls it. Static page uses `?id=<canvasId>`.

- [ ] Write a test with a fake `ctx.webServer.register` and `ctx.connection.requestRejection`: a request without an authenticated browser session receives `401` and never reads page data; a valid ID receives HTML; invalid ID and paths return `400`/`404`.
- [ ] Run the focused test and confirm the missing route export fails.
- [ ] Implement the Host route with `inject = ['webServer', 'connection']` and `ctx.effect(() => ctx.webServer.register(...))`. Call `requestRejection(req)` before method, path, or file handling. Serve only `index.html` and `app.js` with exact MIME types, `no-store`, and a page CSP. Read packaged bytes relative to `import.meta.url`.
- [ ] Add a minimal standalone page that reads the ID from the URL, displays it, and sends `{ protocolVersion: 1, type: 'canvas.node.select', canvasId, requestId, payload: { id, title, type, value } }` to `window.parent` only on user click. No Token, mock remote state, or legacy Web code.
- [ ] Run the focused test and `npm run build`; inspect `npm pack --dry-run` for the two static assets. Commit Task 2.

### Task 3: Sidebar and reverse message

**Files:** Create `src/client/index.tsx`, `src/client/CanvasTab.tsx`, `src/client/message.ts`, `test/message.test.mjs`, `scripts/verify-isolated.mjs`.

**Interfaces:** `parseNodeSelection(value: unknown, expectedCanvasId: CanvasId)` accepts only protocol version 1 with matching ID and bounded strings. `CanvasTab` receives the selected node and calls the current conversation's `inputActions.setDraft`.

- [ ] Write `test/message.test.mjs` for valid payload; reject a different canvas ID, different protocol version, missing fields, and oversize node values.
- [ ] Run the focused test and confirm the missing parser fails.
- [ ] Register one tab type `dsh-resource://canvas/*` and its keyed body through `ctx.sidebarRightTabs` and `ctx.slots`; add a small ID input and Open button for the foundation's manual verification. Use `ctx.effect` for every registration.
- [ ] Render an iframe using `/desktop-canvas/view?id=<id>`. In the message listener check exact `location.origin` and `event.source === frame.current?.contentWindow` before parsing; append a bounded node summary to the current draft.
- [ ] Run `npm test` and `npm run build`. Use the Demo's isolated Profile pattern as a reference while writing a new verifier that installs this package into a copied Profile and confirms plugin load, protected static route, and A/B resource tabs. Commit Task 3.

## Exit check

Build and test from a clean checkout, pack the plugin, and run the isolated verifier. Verify `git status` in Shell, Core, Demo, and legacy Web still has no changes caused by this plan. The package deliberately cannot read real canvas data yet; the next plan adds the authenticated Gateway adapter and POST SSE after service protocol confirmation.

## 本轮结果

- 已在独立仓库实现包构建、数字画布 ID、受 Core Connection 保护的静态页面、右栏资源标签、版本化页面消息与节点摘要输入框接线。
- `npm ci`、`npm test`（6 项）、`npm run typecheck`、打包与隔离 Profile 装载通过；隔离运行时验证了未认证请求被拒、两个画布 ID 页面和内置脚本可访问。
- 隔离脚本验证的是 Host/静态资源装载；尚未在真实桌面页面点击右栏标签或页面按钮，也未接真实画布 GET/SSE。
- 安装时的 peer 警告来自原 Profile 的 `dsh-prompt-enhance@0.2.1` 缺少 React peer；新插件已无未满足的 peer 声明。
