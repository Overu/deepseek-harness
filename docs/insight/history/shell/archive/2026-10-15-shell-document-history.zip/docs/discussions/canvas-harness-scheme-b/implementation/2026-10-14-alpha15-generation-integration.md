# alpha.15：Agent 图片／视频生成接入实施与 review

本阶段研发、review、自动验证、构建及隔离 Core 验证已完成。新增第八个工具 `canvas_run`，用户可以通过对话真正提交已有普通图片／视频节点并局部重跑；复用现有原生业务，不再停留在配置后让用户手动点生成。

真实账号产物和原对话自动反馈仍待用户手测。本轮没有操作画布 103228，没有对真实账号提交生成、安装插件或推送远端；Core 和后端未修改。插件分支 `codex/desktop-canvas-plugin-init`，本地提交 `0f871ee1170ebdb565b188f2d4bce4e91f4ef991`，插件工作区干净。

## 步骤及交付

| 步骤 | 达到的目标 | 核心文件（插件仓库内） |
|---|---|---|
| G1 原生预检与报价 | 真实模型、输入、版本和动态报价；提交前原生容量检查；队列内重核数量、版本和依赖 | `agent-run-preflight.ts`、`workflowCost.ts`、`flowStoreCore.ts` |
| G2 通信与运行记录 | 无 iframe 执行，订阅先于提交；工作流/节点任务 ID 分别保留；本次新产物及未知状态可信交付 | `canvas-run-protocol.ts`、`canvas-run-tracker.ts`、`canvas-generation-monitor.ts`、Host/Client bridge |
| G3 对话和 Jobs | `canvas_run`、真实用户意图计数与确认、Jobs 准入后提交、状态等待和自动通知 | `canvas-run-tools.ts`、`canvas-tool-contracts.ts`、Host index |
| G4 验证与发布准备 | 七工具兼容、主流程及异常回归、实际 Core 类型/服务/工具目录、构建包一致性 | 自动测试、`verify-isolated.mjs`、alpha.15 包 |

`src/...`、`canvas-app/...` 路径均相对 `/Users/boxser.shi/Documents/harness/desktop-canvas-plugin`。完整拆解见[实施计划](../plans/2026-10-14-generation-integration-implementation-plan.md)。

## 执行与通信

1. Agent 使用已保存的真实节点 ID 与最新 confirmed 版本调用 `canvas_run({canvasId,nodeId,expectedVersion})`。scope 固定为单节点，不额外传参数。
2. Host 准备常驻 Context，发送只读 `node.preflight`。Client 校验并复用原生成本接口，返回 `generation:{images,videos}` 与 `quote:{points,originalPoints}`，不产生模型任务。
3. Host 按真实用户输入序号累计数量。超过 30 图／6 视频前通过现有 User Questions 取得真实答复；参数里没有可伪造的 confirmed。当前没有整批执行清单，因此强制计数覆盖“累计越界前确认”，不声称整批首次调用前已经原子预批准。
4. Core Jobs 先检查当前 owner、controller 和额度，再启动 producer。Host/Client 均先建立运行订阅，再派发 `node.run`；批准数量来自可信预检，Agent 不填写。
5. Client 调用原生 `excuteSingle`，沿用 Store、容量、编辑保护及持久化队列，最后报价与校验通过才调用已有 Workflow invoke。输入来自当前 Store 重建的原生单节点 payload，连接的上游需已有可用产物；不运行未准备的上游。
6. 严格接受回执返回 submitted、workflow taskId、版本和 jobId。状态上行是 v4 `canvas.run.state`，沿原有 Client POST；命令仍走 Host SSE。Agent 用现有 `job_output(wait:true)` 和完成通知，不周期读取画布。
7. 原生 monitor 继续原有调度。额外的 tracker 只消费完整权威观察，不从任意 Store.set 推断终态；用接受版本、运行前快照、本次节点任务归属排除旧产物。图片／视频 URL、实际/请求数量及部分完成信息通过 Jobs 回到原对话。

公开七工具名称、文案、超时、参数及字符串输出仍与 alpha.13 固定 fixture 一致。新增工具独立于保存入口，节点编辑和素材导入不会因此自动生成。内部服务桥 v4 要求升级后重启 Harness；原 iframe v2 未改。

## Review 发现并修复

- **提交入口缺失**：开放 run 准备、node.run、submitted 和 run unknown，而不是只增加一个无法调用的声明。
- **报价和发送之间变化**：最终 strict 执行重新报价；队列内重新校验并从最新 Store 构建 payload，保留版本与编辑保护。
- **旧产物误报**：缓存运行前任务 ID/outputs；完整观察证明本次归属后，只交付新 outputs。若后台重复使用旧 URL 且无法区分本次产物，保守报告未确认，不冒用旧图。
- **极快完成及丢提交回执**：双侧先订阅、缓存重放；unknown 保留真实信息及跟踪，不重发命令。工作流任务 ID 与节点任务 ID 不强行等值。
- **监听失败不等于后端失败**：原生 UI 六次异常后的本地 FAILURE 保留；Agent 收到 monitoring_unknown。节点级未解决运行围栏阻止换调用 ID 再生成，可信刷新关联终态后才能释放。
- **终态上报 503 后丢失**：Client 仅重试回执 POST，独立退避，上限 5 秒；不重发生成。测试证明同一 SSE 流、一次 invoke 仍交付终态。
- **缓存压力丢终态**：生成前预留状态空间，最多 8 个活跃跟踪；第九个在生成前拒绝，完成或明确拒绝后释放。
- **已销毁 Context 永久占额度**：独立 reviewer 复现累计 8 次销毁阻断新画布。明确销毁/卸载时释放 observer 和双方预留，保留未确认缓存；普通监控未知和暂时断 SSE 保持可恢复。回归证明第九个新 Context 正常提交。
- **部分新产物被丢弃**：失败仍保留实际新产物；Jobs 返回 actualOutputCount/requestedOutputCount/partial，不宣称全部完成。
- **无关工具配置故障**：普通图片／视频 run readiness 只依模型及模型权限；仍保留原初始化/不确定保存恢复围栏。
- **旧 README 误导 Agent**：当前版边界已改为八工具及真实生成，删除当前时态“所有操作仅保存”的矛盾描述。

根 review 与跨模块独立 review 通过，没有剩余可证实的阻断。临时测试中间态的正则语法和旧 run readiness 断言已修正；以下均为最后一次结果。

## 验证证据

| 项目 | 结果 |
|---|---|
| 插件 Node 测试 | **207/207** |
| Web Agent 测试 | **324/324，25 文件** |
| Host/Client 默认类型 | 通过 |
| 实际 Shell Core 类型 | 通过，直接使用部署 SDK，精准映射 Jobs/view 类型叶子 |
| Web 类型 | 原有 **9 项**，诊断集合逐项一致，**无新增**；不宣称全量通过 |
| 无 iframe 主流程 fixtures | 文生图、参考图生图、图生视频；原生 invoke→权威 monitor→Jobs 新结果；切换对话后仍完成 |
| 真实本地 SSE/POST | 正常/快完成、会话切换、503 上报恢复、Context 销毁资源释放、卸载后未知回放通过 |
| 实际 Core 临时 Profile | 八工具目录、Jobs/User Questions 服务方法、v4 鉴权/SSE/会话同步、服务资源/桌面登录门槛、安装卸载通过；未调用业务生成 |
| 新包内容 | 58 文件逐字节匹配工作区构建；旧 alpha.13/14 SHA256 不变 |

证据：[插件测试](evidence/2026-10-14-alpha15-plugin-tests.tap)、[Web 测试](evidence/2026-10-14-alpha15-web-tests.log)、[类型对比](evidence/2026-10-14-alpha15-web-type-comparison.json)、[包审计](evidence/2026-10-14-alpha15-package-audit.json)、[完整代码变更](evidence/2026-10-14-alpha15-generation.patch)、[检查汇总](2026-10-14-alpha15-checks.json)。隔离日志仅归档 PASS 摘要，不保存临时浏览器认证信息。

## 包与手测

[alpha.15 插件包](/Users/boxser.shi/Documents/harness/desktop-canvas-plugin/insight-ai-desktop-canvas-plugin-0.3.0-alpha.15.tgz)，14,478,591 字节。

SHA256：`4b1d1ec37eec43c468c76c83a8dafce8be0e8b0096a1a49f13017308624094f9`。

按[产品角色手测步骤](2026-10-14-generation-manual-acceptance.md)先验收一张图片、局部重跑、一条视频，再检查异常细节。真实模型质量、实际 workflow/node taskId 语义及原对话完成反馈必须用实账确认，不能以 fixtures 替代。

本阶段不开放工具节点创建、抠图工具、模板或整图执行。关闭画布视图/切换对话继续跟踪；完全退出客户端后不承诺自动恢复原会话通知。`job_kill` 只停止本地跟踪，不表示后端生成已取消。
