# Canvas result gallery implementation plan

> **For agentic workers:** Follow the approved design task by task with independent review. The user has authorized implementation in this conversation; no additional execution-choice step is required.

**Goal:** Replace the plugin's text-only result footer with a compact media gallery and remove its visible test-only canvas-ID control.

**Architecture:** Keep alpha.16's trusted source persistence, original turn scoping and navigation. Project those sources into at most four media thumbnails. Resolve the real canvas name through the existing authenticated snapshot GET, and retain the invisible Session bridge independently of the removed test UI.

**Tech Stack:** Existing React 18 Client, Cordis plugin slots, native image/video elements, ResizeObserver, Node tests, esbuild and the existing plugin pack script.

## Global constraints

- Core, backend and native canvas business/UI behavior remain unchanged.
- Use the real canvas title without media counts; fallback only when a read fails.
- One header button; one actual output focuses its node, multiple actual outputs open the canvas normally, including when only four are previewed.
- Square thumbnails use proportional contain. Card width wraps its header/gallery, rather than filling the conversation.
- Four outputs use one row when it fits, otherwise two columns (2+2); three use 3 or 2+1. Extremely narrow containers fall back to one column without overflow.
- Only this turn's trusted generated results appear. Ordinary attachments/files are unchanged. No generation is submitted by loading, resizing or navigating a card.
- No new dependency, source schema migration, polling, image download or model call.

## Task G1: Gallery projection, title read and result UI

**Files:** Plugin `src/client/canvas-result-gallery.ts`, `src/client/CanvasResults.tsx`, `src/client/canvas-results.ts`; tests `test/canvas-result-gallery.test.mjs`, `test/canvas-results-client.test.mjs`.

**Interfaces:**

```ts
interface CanvasResultProduct { key: string; nodeId: string; url: string; kind: 'image' | 'video' | 'unknown' }
function canvasResultProducts(sources: readonly CanvasResultSource[]): CanvasResultProduct[]
function canvasResultColumns(count: number, availableWidth: number): number
// Added to the existing Client results store; requests deduplicate only while in flight.
getCanvasTitle(canvasId: string): Promise<string | undefined>
```

- [x] Project real outputs, cap previews at four and base focus on the complete output list, not source/node count or truncated previews.
- [x] Read `GET /desktop-canvas/api/snapshot?id=<id>` using `credentials:'same-origin'`; validate returned canvasId/name. Abort pending requests on reset/dispose, discard stale identity results, and allow a failed read to retry on a future mount.
- [x] Keep separate focused card/thumbnail components in `CanvasResults.tsx`. Header contains only title and one official Button. Image/video failure keeps a square fallback and does not alter navigation identity.
- [x] Observe available conversation width and select columns before wrap. Use intrinsic card width, constrained by available width; CSS `aspect-ratio:1`, `object-fit:contain`, and no autoplay.
- [x] Verify one output, two outputs from one node, several source nodes, >4 outputs, unknown mixed media, title failures/reset and no writes from title reads.

## Task G2: Remove test controls without disconnecting the Agent

**Files:** Plugin `src/client/index.tsx`, `test/canvas-service-build.test.mjs`, `docs/acceptance.md`.

- [x] Delete `OpenCanvas`, numeric input and adjacent button; remove unused imports.
- [x] Preserve the invisible `SessionControl` with `bridge.retainSession(canvasSessionId)` and `return null` in the existing scoped lifecycle.
- [x] Check duplicate mounts attach once, both render null, teardown releases correctly, and real result/link navigation still works.

## Task G3: Verification, review and release

**Files:** Plugin `package.json`, `package-lock.json`, `README.md`; Shell discussion implementation report, manual acceptance and evidence.

- [x] Run targeted tests and the full Plugin suite; check default types and actual deployed Core SDK types.
- [x] Render the real new component in a local browser fixture with local image/video data. Inspect widths, square geometry, 4-in-one-row / 2+2 / 2+1, long title, failure fallback and single/multi navigation.
- [x] Independently review the final diff and fix supported findings.
- [x] Build and pack `0.3.0-alpha.17` using existing tooling. Check the actual archive, version, relevant Client bytes and SHA256; retain alpha.16.
- [x] Record limits honestly: local media/identity fixtures do not replace real-account URL and client hand testing. Provide plain-language manual steps. Do not install into the user's live client or submit generation as part of development verification.

## Manual acceptance target

After alpha.17 installation, the original successfully bound alpha.16 conversation should show a real canvas name and thumbnails without regenerating. One product opens and focuses; several products only open. A wide message displays four in one row, a narrower one shows 2+2 (three: 2+1); the frame stays snug. Ordinary attachment-only conversations have no canvas card. The numeric canvas-ID test control is absent while closed-canvas Agent reads/edits still work.
